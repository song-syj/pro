#ifndef _THREADS_H
#define _THREADS_H

#include <pthread.h>
#include <assert.h>
#include <stdint.h>
#include <vector>
#include <deque>

class CondVar;

class Mutex {
public:
	Mutex()
	{
		bool res = pthread_mutexattr_init(&attribs);
		assert(!res);
		res = pthread_mutexattr_settype(&attribs,PTHREAD_MUTEX_RECURSIVE);
		assert(!res);
		res = pthread_mutex_init(&mutex,&attribs);
		assert(!res);
	}

	~Mutex()
	{
		pthread_mutex_destroy(&mutex);
		bool res = pthread_mutexattr_destroy(&attribs);
		assert(!res);
	}

	void lock() { pthread_mutex_lock(&mutex); }

	void unlock() { pthread_mutex_unlock(&mutex); }

private:
	pthread_mutex_t mutex;
	pthread_mutexattr_t attribs;
	friend class CondVar;
};

class ScopedLock {
public:
	ScopedLock(Mutex wmutex)
		:mutex(wmutex) {mutex.lock();}
	~ScopedLock() {mutex.unlock();}

private:
	Mutex& mutex;
};

class CondVar {
public:
	CondVar() {bool s = pthread_cond_init(&cond_var, NULL); assert(!s);}
	~CondVar() {pthread_cond_destroy(&cond_var);}
	void Wait(Mutex &mutex_t) { pthread_cond_wait(&cond_var, &mutex_t.mutex);}
	void Wait(Mutex &mutex_t, uint32_t timeout) {}
	void Signal() {pthread_cond_signal(&cond_var);}
	void Broadcast() {pthread_cond_broadcast(&cond_var);};
private:
	pthread_cond_t cond_var;
};

class Task {
public:
	Task(void *(*task_fn)(void *), void *arg)
	{
		this ->arg = arg;
		task = task_fn;
	}
	void Run() { task(arg); }
private:
	void *(*task)(void *);
	void *arg;
};

class Thread {
public:
    Thread(size_t stacksize = (65536)*4)
		:tid(0), attr(), stack_size(stacksize){}
    ~Thread() {pthread_attr_destroy(&attr);}

    void Start(void* (*task)(void *), void *arg)
    {
        bool res;
        res = pthread_attr_init(&attr);
        assert(!res);
        res = pthread_attr_setstacksize(&attr,stack_size);
        assert(!res);
        res = pthread_create(&tid, &attr, task, arg);
        assert(!res);
    }
    void Join(void **rval_ptr = NULL)
    {
        int s = pthread_join(tid, rval_ptr);
        assert(!s);
    }
private:
    pthread_t tid;
    pthread_attr_t attr;
    size_t stack_size;

};

class ThreadPool {
public:
	typedef enum PoolState {POOL_START, POOL_STOP} PoolState;
	ThreadPool (int size = 0) :pool_size(size),pool_state (POOL_STOP) {}
	void SetSize(int size) {pool_size = size;}
	bool Init();
	bool Destroy();
	bool AddTask(Task *);
private:
	static void * ExectueThread(void *arg);
	int pool_size;
	PoolState pool_state;
	std::vector<Thread *> threads_vect;
	std::deque<Task *> task_deque;
	Mutex task_mutex;
	CondVar task_cond_var;
};

#endif
