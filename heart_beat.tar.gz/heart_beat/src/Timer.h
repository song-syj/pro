/*
 * Timer.h
 *
 *  Created on: Jul 22, 2014
 *      Author: song
 */

#ifndef TIMER_H_
#define TIMER_H_

#include<sys/time.h>
#include<signal.h>
#include<stdint.h>

class Timer {
public:
	Timer();
	void Set(void (*fn)(int signo), int sec, int type = ITIMER_VIRTUAL);
	void Start();
	void Stop();
	void Init();
	~Timer();
private:
	uint32_t interval;
	uint32_t precision;
	void (*timer_hander)(int signo);
};

#endif /* TIMER_H_ */
