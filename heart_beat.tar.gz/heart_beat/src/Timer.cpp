/*
 * Timer.cpp
 *
 *  Created on: Jul 22, 2014
 *      Author: song
 */

#include "Timer.h"
#include <stdlib.h>

void Timer::Set(void (*fn)(int signo), int sec, int type)
{
	interval = sec;
	precision = type;
	timer_hander = fn;
}


void Timer::Start()
{
	struct itimerval val;
	val.it_value.tv_sec = interval;
	val.it_value.tv_usec = 0;
	val.it_interval = val.it_value;
	setitimer(precision, &val, NULL);
}

void Timer::Stop()
{
	struct itimerval val;
	val.it_value.tv_sec = 0;
	val.it_value.tv_usec = 0;
	val.it_interval = val.it_value;
	setitimer(precision, &val, NULL);
}

void Timer::Init()
{
	int signo;
	switch(precision) {
	case ITIMER_REAL:
		signo = SIGALRM;
		break;
	case ITIMER_VIRTUAL:
		signo = SIGVTALRM;
		break;
	case ITIMER_PROF:
		signo = SIGPROF;
		break;
	}
	signal(signo, timer_hander);
}
