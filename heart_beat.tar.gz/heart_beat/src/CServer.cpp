/*
 * CServer.cpp
 *
 *  Created on: Jul 23, 2014
 *      Author: song
 */

#include "CServer.h"
#include "MessageUnit.h"
#include "Config.h"
#include <stdlib.h>
#include <stdio.h>
#include <sys/epoll.h>
#include <unistd.h>
#include <sys/time.h>
#include <list>

#define MAX_EVENTS 1000
#define MAX_SQL_LEN 300


typedef struct ReqPair{
	int req_fd;
	CServer *ptr_server;
	ReqPair(int fd, CServer *p) :req_fd(fd), ptr_server(p){}
}ReqPair;


static bool WritePackage(int fd, DataPackage &data_pack, uint32_t timeout)
{
	int send_len = sizeof(data_pack) + data_pack.length;

	if (send_len == TCPSocket::Send(fd, (char *)&data_pack, send_len, timeout))
		return true;
	else {
		return false;
	}
}

static DataPackage* ReadPackage(int fd, uint32_t timeout)
{
	DataPackage head;
	int read_len ;
	read_len = sizeof(head);
	int ret = TCPSocket::Recv(fd, (char *)&head, read_len, timeout);

	if (ret == 0) {
		log_warning("Read Package ret = %d", ret);
		close(fd);
		return NULL;
	}

	if (ret != read_len) {
		log_warning("Read Package ret = %d", ret);
		return NULL;
	}

	if (read_len > 1024)
		return NULL;

	DataPackage *ptr_pack = (DataPackage *)malloc(sizeof(DataPackage) + head.length);
	*ptr_pack = head;
	if (ptr_pack == NULL) {
		log_error("malloc DataPackage for Read error");
		return NULL;
	}

	read_len = ptr_pack->length;

	ret = TCPSocket::Recv(fd, (char *)ptr_pack->data, read_len, timeout);
	if (ret != read_len) {
		log_warning("Read Package ret = %d", ret);
		return NULL;
	}

	return ptr_pack;
}

void CServer::Init(const char *app,const char *config_file)
{
	std::string ip_addr;
	int port;
	int pool_size;
	int link_size;
	int log_level;
	Config conf_set(config_file);

	port = conf_set.Read("server_port", 8080);
	pool_size = conf_set.Read("pool_size", 200);
	link_size = conf_set.Read("link_size", 1000);
	ip_addr = conf_set.Read("ip_addr", ip_addr);
	log_level = conf_set.Read("log_level", 6);
	
	// init log 
	log_level = conf_set.Read("log_level", 6);
	init_log(app, "../log");
	set_log_level(log_level);


	thread_pool.SetSize(pool_size);
	thread_pool.Init();
	if(!server_sock.Bind(ip_addr.c_str(), port, true)) {
		log_crit("socket bind error");
		exit(1);
		return;
	}

	peer_list.ClearAllPeer();
	server_start = false;
	try {
		mutexs = new Mutex[link_size+4];
	}catch (const std::bad_alloc& e){
		 log_crit("mutexs array for fd read/write alloc errror");
		exit(0);
	}
	
	//config mysql
	std::string host;
	int db_port;
	std::string db_name;
	std::string user_name;
	std::string password;
	std::string charset;

	host = conf_set.Read("host", host);
	db_port = conf_set.Read("db_port", 3306);
	db_name = conf_set.Read("db_name", db_name);
	user_name = conf_set.Read("user_name", user_name);
	password = conf_set.Read("password", password);
	charset = conf_set.Read("charset", charset);
	if(charset.empty()) charset = "utf8";

	db_conn.Init(host.c_str(), db_port, db_name.c_str(), 
			user_name.c_str(), password.c_str(), charset.c_str());

	if (!db_conn.Connect()) {
		log_crit("Mysql Connect fail");
		exit(1);
	} else {
		log_info("Mysql Connect success");
	}
}

void CServer::Start()
{
	server_sock.Listen(2000);
	server_start = true;
	thread_listen_loop.Start(ListenLoop, this);
	thread_heart_check.Start(HeartBeatCheck, this);
	log_info("server start"); 
}

void * CServer::RecvProcess(void *arg)
{
	ReqPair *req_pair  = (ReqPair *)arg;

	int client_fd = req_pair->req_fd;
	CServer *ptr_server = req_pair->ptr_server;
	delete req_pair;

	ptr_server->mutexs[client_fd].lock();
	DataPackage *ptr_recv_pack = ReadPackage(client_fd, 1000);
	if (ptr_recv_pack == NULL) {
		log_warning("Read no Package from fd = %d", client_fd);
		ptr_server->mutexs[client_fd].unlock();
		return NULL;
	}
	ptr_server->mutexs[client_fd].unlock();

	switch((MessageUnit::MessageType)(ptr_recv_pack->type)) {
		case MessageUnit::USER_LOGIN_REQUEST:
			{
				CServer::UserLoginResponse(client_fd, ptr_recv_pack, ptr_server);
			}break;

		case MessageUnit::USER_LIST_REQUEST:
			{
				CServer::UserListResponse(client_fd, ptr_recv_pack, ptr_server);
			}
			break;
		case MessageUnit::HEART_BEAT_QUERY:
			{
				CServer::HeartBeatResponse(client_fd, ptr_recv_pack, ptr_server);
			}break;

		case MessageUnit::USER_CHAR_MESSAGE: 
			{
				CServer::RetransmitChatMessage(client_fd, ptr_recv_pack, ptr_server);
			}break;
		case MessageUnit::USER_MESSAGE_RECV_ACK:
			break;
		case MessageUnit::USER_CHAT_RECORDS_REQUEST:
			{
				CServer::UserChatRecordsResponse(client_fd, ptr_recv_pack, ptr_server);

			} break;
		case MessageUnit::USER_LOGOUT_REQUEST:
			{
				CServer::LogoutProcess(client_fd, ptr_recv_pack, ptr_server);
			}
			break;
		default:
			break;
	}

	free(ptr_recv_pack);

	return (void *)0;
}

void * CServer::HeartBeatCheck(void *arg)
{
	CServer *ptr_server = (CServer *)arg;
	while(ptr_server->server_start) {
		struct timeval tv;
		gettimeofday(&tv, NULL);
		uint64_t curr_time = tv.tv_sec * 1000 + tv.tv_usec / 1000;

		ptr_server->peer_list.HeartTimeCheck(curr_time);

		sleep(5);
		ptr_server->peer_list.PrintPeers();
	}
	return (void *)0;
}

void* CServer::ListenLoop(void *arg)
{
	CServer *ptr_server = (CServer *)arg;
	ptr_server->server_sock.NonBlocking();
	struct epoll_event ev;
	struct epoll_event *events = (struct epoll_event *)malloc(sizeof(struct epoll_event) * MAX_EVENTS);

	if (events == NULL) {
		log_crit("epoll_events malloc");
		exit(EXIT_FAILURE);
	}

	int epollfd = epoll_create(10);
	if (epollfd == -1) {
		log_crit("epoll_create");
		exit(EXIT_FAILURE);
	}

	int listen_sock = ptr_server->server_sock.GetSocketFd();

	ev.events = EPOLLIN;
	ev.data.fd = listen_sock;
	if (epoll_ctl(epollfd, EPOLL_CTL_ADD, listen_sock, &ev) == -1) {
		log_crit("epoll_ctl: listen_sock");
		exit(EXIT_FAILURE);
	}

	for (;;) {
		int nfds = epoll_wait(epollfd, events, MAX_EVENTS, -1);
		if (nfds == -1) {
			log_crit("epoll_pwait");
			exit(EXIT_FAILURE);
		}

		for (int n = 0; n < nfds; ++n) {
			if (events[n].data.fd == listen_sock) {
				struct sockaddr_in client_addr;
				socklen_t addrlen = sizeof(client_addr);
				memset(&client_addr, 0, addrlen);
				int conn_sock;
				conn_sock = ptr_server->server_sock.Accept((struct sockaddr *) &client_addr, &addrlen);
				if (conn_sock == -1) {
					log_crit("accept");
					exit(EXIT_FAILURE);
				}
				TCPSocket::NonBlocking(conn_sock);
				ev.events = EPOLLIN;
				ev.data.fd = conn_sock;
				if (epoll_ctl(epollfd, EPOLL_CTL_ADD, conn_sock, &ev) == -1) {
					log_crit("epoll_ctl: conn_sock");
					exit(EXIT_FAILURE);
				}


				log_info("fd: %d aceept client from ip: %s port: %d",
					   	conn_sock, inet_ntoa(client_addr.sin_addr),client_addr.sin_port);
					 
			} else {
				ptr_server->thread_pool.AddTask(
						new Task(RecvProcess,new ReqPair(events[n].data.fd,ptr_server)));
			}
		}
		usleep(100000);
	}

	free(events);

}

bool CServer::UserLoginVerify(const uint32_t uid, const char *passwd)
{
	char stmt_str[MAX_SQL_LEN];
	CDBRecordSet record_set;
	std::string escaped_passwd;

	db_conn.EscapeString(escaped_passwd, passwd, strlen(passwd));
	snprintf(stmt_str, MAX_SQL_LEN, 
			"select * from user_info where user_id = %d and password = '%s'", uid, escaped_passwd.c_str());

	return (db_conn.SelectQuery(stmt_str, record_set) && (!record_set.empty()));
}

bool CServer::UpdataUserLoginInfo(const uint32_t uid, const int ip_addr, PeerInfo &peer_info)
{
	char stmt_str[MAX_SQL_LEN];
	CDBRecordSet record_set;
	snprintf(stmt_str, MAX_SQL_LEN, 
			"select * from user_info where user_id = %d",
		   uid);
	if(!db_conn.SelectQuery(stmt_str, record_set)) {
		return false;
	}
	std::string user_name = record_set[0]["user_name"];
	strcpy(peer_info.username, user_name.c_str());
	snprintf(stmt_str, MAX_SQL_LEN, 
			"update user_info set ip_address= %d where user_id = %d",
		   ip_addr, uid);
	int affected_rows;
	return db_conn.ExecuteQuery(stmt_str, affected_rows);
}

void CServer::UserLoginResponse(int client_fd, DataPackage *ptr_recv_pack, CServer *ptr_server)
{
	LoginRequestMessage login_req_msg;
	login_req_msg.parse(*ptr_recv_pack);
	log_info("receive user_id:%d login request", login_req_msg.user_id);

	if (ptr_server->UserLoginVerify(
				login_req_msg.user_id, login_req_msg.password.c_str())) {
		

		struct sockaddr_in client_addr = TCPSocket::GetRemoteAddr(client_fd);
		PeerInfo peer_info;
		if(!ptr_server->UpdataUserLoginInfo(
					login_req_msg.user_id, 
					client_addr.sin_addr.s_addr, 
					peer_info)) {
			return;
		}

		peer_info.user_id = login_req_msg.user_id;
		peer_info.ip_addr = client_addr.sin_addr.s_addr;
		peer_info.port = client_addr.sin_port;

		PeerFDNode peer_node;
		struct timeval tv;
		gettimeofday(&tv, NULL);
		peer_node.heart_time = tv.tv_sec * 1000 + tv.tv_usec / 1000;

		peer_node.blogin = true;
		peer_node.fd = client_fd;
		peer_node.peer_info = peer_info;
		ptr_server->peer_list.AddPeer(peer_node);

		//send login success msg
		LoginSucessMessage login_success_msg(peer_info);
		DataPackage *ptr_send_pack = login_success_msg.assemble();
		if(ptr_send_pack == NULL) {
			return;
		}

		log_info("send login sucess message to %d", login_req_msg.user_id);
		ptr_server->mutexs[client_fd].lock();
		if(!WritePackage(client_fd, *ptr_send_pack, 1000)) {
			log_warning("write package to fd = %d error", client_fd);
		}
		ptr_server->mutexs[client_fd].unlock();
		free(ptr_send_pack);

	} else {
		//send login fail msg
		LoginFailMessage login_fail_msg;
		DataPackage *ptr_send_pack = login_fail_msg.assemble();
		if(ptr_send_pack == NULL) {
			return;
		}

		log_info("send login fail message to %d", login_req_msg.user_id);
		ptr_server->mutexs[client_fd].lock();
		if(!WritePackage(client_fd, *ptr_send_pack, 1000)) {
			log_warning("write package to fd = %d error", client_fd);
		}
		ptr_server->mutexs[client_fd].unlock();
		free(ptr_send_pack);
	}

}

void CServer::UserListResponse(int client_fd, DataPackage *ptr_recv_pack, CServer *ptr_server)
{
	log_info("receive fd =%d, user list request", client_fd);
	UserListAckMessage user_list_req;
	ptr_server->peer_list.GetPeerList(user_list_req.peer_list);
	DataPackage *ptr_send_pack = user_list_req.assemble();
	if(ptr_send_pack == NULL) {
		return;
	}

	/*PeerListInfo *pList = (PeerListInfo *)(ptr_send_pack->data);
	  std::cout << "Show List in UserListRequest" << std::endl;
	  for (int i = 0; i < pList->size; i++) {
	  std::cout <<pList->peerlist[i].username<< std::endl;
	  }*/

	log_info("send user list message");
	ptr_server->mutexs[client_fd].lock();
	if(!WritePackage(client_fd, *ptr_send_pack, 1000)) {
		log_warning("write package to fd = %d error", client_fd);
	}
	ptr_server->mutexs[client_fd].unlock();

	free(ptr_send_pack);

	UserListComplete user_list_complete;
	ptr_send_pack = user_list_complete.assemble();
	log_info("send user list complete");
	ptr_server->mutexs[client_fd].lock();
	if(!WritePackage(client_fd, *ptr_send_pack, 1000)) {
		log_warning("write package to fd = %d error", client_fd);
	}
	ptr_server->mutexs[client_fd].unlock();

	free(ptr_send_pack);
}

void CServer::HeartBeatResponse(int client_fd, DataPackage *ptr_recv_pack, CServer *ptr_server)
{
	log_info("receive fd =%d heart beat package", client_fd);
	// update heartbeat time
	struct timeval tv;
	gettimeofday(&tv, NULL);
	uint64_t curr_time = tv.tv_sec * 1000 + tv.tv_usec / 1000;
	ptr_server->peer_list.UpdateHeartTime(client_fd,curr_time);

	HeartBeatAck heart_beat_ack;
	DataPackage *ptr_send_pack = heart_beat_ack.assemble();

	log_info("send heart beat ack  message");
	ptr_server->mutexs[client_fd].lock();
	if(!WritePackage(client_fd, *ptr_send_pack, 1000)) {
		log_warning("write package to fd = %d error", client_fd);
	}
	ptr_server->mutexs[client_fd].unlock();

	free(ptr_send_pack);
}


bool CServer::AddChatRecord(const PeerInfo &src, const PeerInfo &des, const std::string &text)
{
	char stmt_str[MAX_SQL_LEN];
	std::string escaped_src_name;
	std::string escaped_des_name;
	std::string escaped_text;
	
	db_conn.EscapeString(escaped_src_name, src.username, strlen(src.username));
	db_conn.EscapeString(escaped_des_name, des.username, strlen(des.username));
	db_conn.EscapeString(escaped_text, text.c_str(), text.length());
	snprintf(stmt_str, MAX_SQL_LEN, 
			"insert into chat_record(src_id, src_name, des_id, des_name, msg_content) values(%d, '%s', %d, '%s', '%s')",
		    src.user_id, escaped_src_name.c_str(), des.user_id, escaped_des_name.c_str(), escaped_text.c_str());
	int affected_rows;
	return db_conn.ExecuteQuery(stmt_str, affected_rows);

}

void CServer::RetransmitChatMessage(int client_fd, DataPackage *ptr_recv_pack, CServer *ptr_server)
{
	// retransmit the msg
	UserChatMessage chat_msg; 
	chat_msg.parse(*ptr_recv_pack);
	log_info("receive fd =%d user chat msg from %s to %s", client_fd
			, chat_msg.GetDesPeer().username
			,chat_msg.GetSrcPeer().username);

	PeerFDNode des_info;
	bool find = ptr_server->peer_list.GetPeer(chat_msg.GetDesPeer().username,des_info);

	if (find) {
		log_info("find desc user's infornation");
		log_info("send message recv  ack message");
		MessageRecvAck msg_recv_ack;
		DataPackage *ptr_send_pack = msg_recv_ack.assemble();
		if (ptr_send_pack == NULL) {
			return;
		}
		ptr_server->mutexs[client_fd].lock();
		if(!WritePackage(client_fd, *ptr_send_pack, 1000)) {
			log_warning("write package to fd = %d error", client_fd);
		}
		ptr_server->mutexs[client_fd].unlock();

		free(ptr_send_pack);

		int des_fd = des_info.fd;
		ptr_server->mutexs[client_fd].lock();
		if(!WritePackage(des_fd, *ptr_recv_pack, 1000)) {
			log_warning("write package to fd = %d error", client_fd);
		}
		ptr_server->mutexs[client_fd].unlock();

		ptr_server->AddChatRecord(chat_msg.GetSrcPeer(), chat_msg.GetDesPeer(), chat_msg.GetChatContent());

	}else {
		log_info("can't find desc user's infornation");
		log_info("send message recv fail message");
		MessageRecvFail msg_recv_fail;
		DataPackage *ptr_send_pack = msg_recv_fail.assemble();
		ptr_server->mutexs[client_fd].lock();
		if(!WritePackage(client_fd, *ptr_send_pack, 1000)) {
			log_warning("write package to fd = %d error", client_fd);
		}
		ptr_server->mutexs[client_fd].unlock();

		free(ptr_send_pack);
	}
}

bool CServer::GetUserRecords(uint32_t uid, ChatRecordItems &list) 
{
	char stmt_str[MAX_SQL_LEN];
	CDBRecordSet record_set;
	snprintf(stmt_str, MAX_SQL_LEN, 
			"select * from chat_record where src_id = %d or des_id = %d",
		   uid, uid);
	if(!db_conn.SelectQuery(stmt_str, record_set)) {
		return false;
	}

	list.clear();
	ChatRecord tmp_record;
	for(size_t i = 0; i < record_set.size(); i++) {
		tmp_record.src_id = atoi(record_set[i]["src_id"].c_str());
		tmp_record.des_id = atoi(record_set[i]["des_id"].c_str());
		strncpy(tmp_record.src_name, record_set[i]["src_name"].c_str(),MAX_USERNAME_LEN);
		strncpy(tmp_record.des_name, record_set[i]["des_name"].c_str(),MAX_USERNAME_LEN);
		strncpy(tmp_record.text, record_set[i]["msg_content"].c_str(),MAX_CHAT_MESSAGE);
		strncpy(tmp_record.time, record_set[i]["time"].c_str(),TIME_LEN);

		list.push_back(tmp_record);
	}

	return true;
}

void CServer::UserChatRecordsResponse(int client_fd, DataPackage *ptr_recv_pack, CServer *ptr_server)
{
	log_info("receive fd =%d user chat records request", client_fd);

	PeerFDNode remote_info;
	bool find = ptr_server->peer_list.GetPeer(client_fd, remote_info);

	if (find == false) {
		log_info("remote user not in the list");
		return;
	}

	ChatRecordItems record_items;
	if(!ptr_server->GetUserRecords(remote_info.peer_info.user_id, record_items))  {
		log_info("get remote user records error");
		return;
	}

	// return user chat records 
	log_info("send fd = %d user chat record ack message", client_fd);
	UserChatRecordAckMessage chat_record_ack(record_items);
	DataPackage *ptr_send_pack = chat_record_ack.assemble();
	if(ptr_send_pack == NULL) {
		log_error("assemble user chat record ack message error");
		return;
	}

	ptr_server->mutexs[client_fd].lock();
	if(!WritePackage(client_fd, *ptr_send_pack, 1000)) {
		log_warning("write package to fd = %d error", client_fd);
	}
	ptr_server->mutexs[client_fd].unlock();

	free(ptr_send_pack);

	// send user chat record complete message
	log_info("send fd = %d user chat record complete message", client_fd);
	UserChatRecordCompleteMessage chat_record_complete;
	ptr_send_pack = chat_record_complete.assemble();
	if(ptr_send_pack == NULL) {
		log_error("assemble user chat record complete message error");
		return;
	}

	ptr_server->mutexs[client_fd].lock();
	if(!WritePackage(client_fd, *ptr_send_pack, 1000)) {
		log_warning("write package to fd = %d error", client_fd);
	}
	ptr_server->mutexs[client_fd].unlock();

	free(ptr_send_pack);

}

void CServer::LogoutProcess(int client_fd, DataPackage *ptr_recv_pack, CServer *ptr_server)
{
	PeerFDNode client_info;
	ptr_server->peer_list.GetPeer(client_fd, client_info);
	log_info("%s logout!", client_info.peer_info.username);
	ptr_server->peer_list.DeletePeer(client_fd);
}
