#ifndef LOG_H
#define LOG_H

#include <sys/cdefs.h>
#include <stdio.h>
#include <sys/syscall.h>

#define gettid() syscall(__NR_gettid)

extern int __log_level__;
extern bool __log_pid__;

#define log_generic(lvl, fmt, args...)	 write_log(lvl, __FILE__, __FUNCTION__, __LINE__ , fmt, ##args)
#define log_boot(fmt, args...)		log_generic(-1, fmt, ##args)
#define log_emerg(fmt, args...)	log_generic(0, fmt, ##args)
#define log_alert(fmt, args...)		log_generic(1, fmt, ##args)
#define log_crit(fmt, args...)		log_generic(2, fmt, ##args)
#define log_error(fmt, args...)		log_generic(3, fmt, ##args)
#define log_warning(fmt, args...)	do{ if(__log_level__>=4)log_generic(4, fmt, ##args); } while(0)
#define log_notice(fmt, args...)	do{ if(__log_level__>=5)log_generic(5, fmt, ##args); } while(0)
#define log_info(fmt, args...)		do{ if(__log_level__>=6)log_generic(6, fmt, ##args); } while(0)
#define log_debug(fmt, args...)	do{ if(__log_level__>=7)log_generic(7, fmt, ##args); } while(0)

extern void init_log (const char *app, const char *dir = NULL);
extern void set_log_level(int);
extern void set_log_pid(bool);
extern void write_log (int, const char*, const char *, int, const char *, ...) __attribute__((format(__printf__,5,6)));

#endif

