#include "CMysqlDB.h"
#include <string.h>
#include "log.h"
#include<iostream>

#define MAX_SQL_LEN 300
using namespace std;

int main(int argc, char *argv[])
{
	// init log 
	init_log(argv[0], "../log");
	set_log_level(7);

	CDBConnection db_conn;
	db_conn.Init("localhost", 3306,"chat_user", "song","song", "utf8");
	if(!db_conn.Connect()) {
		cout << "mysql connect error" << endl;
		return -1;
	} else {
			cout << "mysql connect success" << endl;
	}
	/*int affected_rows;
	if (db_conn.ExecuteQuery("insert into user_info(user_id, user_name, ip_address, password) value(244430217,'song',1234,'song')", affected_rows)) {
		cout << "insert success" << endl;
	} else  {
		cout << "insert error" << endl;
	}*/

	CDBRecordSet record_res;
	char stmt_str[MAX_SQL_LEN];
	const char* passwd = "song";
	int uid = 244430217;
	CDBRecordSet record_set;
	string escaped_passwd;

	db_conn.EscapeString(escaped_passwd, passwd, strlen(passwd));
	cout << "escaped passwd:" << escaped_passwd << endl;
	snprintf(stmt_str, MAX_SQL_LEN, 
			"select * from user_info where user_id = %d and password = '%s'", uid, escaped_passwd.c_str());

	if(db_conn.SelectQuery(stmt_str, record_set) && (!record_set.empty())) {
		cout << "correct escape" << endl;
	} else {
		cout << "error escape" << endl;
	}
	/*if (db_conn.SelectQuery("select * from user_info where password = 'song'", record_res)) {
		for (size_t i = 0; i < record_res.size(); i++) {
			cout << "user_id: " << record_res[i]["user_id"] << endl;
			cout << "user_name: " << record_res[i]["user_name"] << endl;
			cout << "login_last_time: " << record_res[i]["login_last_time"] << endl;
			cout << "ip_address: " << record_res[i]["ip_address"] << endl;
			cout << "password: " << record_res[i]["password"] << endl;
			cout << endl;

		}
	} else {
		cout << "select error" << endl;
	}*/

	db_conn.Close();

	return 0;
}
