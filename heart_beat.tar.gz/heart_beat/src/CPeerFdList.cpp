#include "CPeerFdList.h"
#include "log.h"

void CPeerFdList::AddPeer(PeerFDNode &peer_node)
{
	bool find = false;

	mutex.lock();
	for (std::list<PeerFDNode>::iterator
			iter = peer_list.begin(); 
			iter != peer_list.end(); iter++) {
		if (iter->blogin == false &&
				!strcmp(peer_node.peer_info.username,
				   	iter->peer_info.username)) {
			*iter = peer_node;
			iter->blogin = true;
			find = true;
		}

	}

	if (!find) {
		peer_list.push_front(peer_node);
	}

	mutex.unlock();
}

bool CPeerFdList::GetPeer(int fd, PeerFDNode &goal_peer)
{
	mutex.lock();
	bool find = false;
	for(std::list<PeerFDNode>::iterator
			iter = peer_list.begin();
		iter != peer_list.end(); iter++) {
		if(iter->blogin && fd == iter->fd) {
			goal_peer = *iter;
			find = true;
			break;
		}
	}
	mutex.unlock();

	return find;
}

bool CPeerFdList::GetPeer(const char *peer_name, PeerFDNode &goal_peer)
{
	mutex.lock();
	bool find = false;
	for(std::list<PeerFDNode>::iterator
			iter = peer_list.begin();
		iter != peer_list.end(); iter++) {
		if(iter->blogin && !strcmp(iter->peer_info.username, peer_name)) {
			goal_peer = *iter;
			find = true;
			break;
		}
	}

	mutex.unlock();

	return find;
}

void CPeerFdList::GetPeerList(std::list<PeerInfo> &user_list)
{
	mutex.lock();
	user_list.clear();
	for(std::list<PeerFDNode>::iterator
			iter = peer_list.begin();
		iter != peer_list.end(); iter++) {
		if(iter->blogin) {
			user_list.push_back(iter->peer_info);
		}
	}
	mutex.unlock();
	log_info("Get Peer List :");
	PrintPeers();
}
void CPeerFdList::SetPeerName(int fd, const char *peer_name)
{
	mutex.lock();
	for(std::list<PeerFDNode>::iterator
			iter = peer_list.begin();
		iter != peer_list.end(); iter++) {
		if(fd == iter->fd && iter->blogin == false) {
			strcpy(iter->peer_info.username,peer_name);
			iter->blogin = true;
			break;
		}
	}
	mutex.unlock();
}

void CPeerFdList::UpdateHeartTime(int fd, uint64_t updata_time)
{
	mutex.lock();
	for(std::list<PeerFDNode>::iterator
			iter = peer_list.begin();
		iter != peer_list.end(); iter++) {
		if(iter->blogin && fd == iter->fd) {
			iter->heart_time = updata_time;
			break;
		}
	}
	mutex.unlock();
}

void CPeerFdList::HeartTimeCheck(uint64_t curr_time)
{
	mutex.lock();
	for(std::list<PeerFDNode>::iterator
			iter = peer_list.begin();
		iter != peer_list.end(); iter++) {
		if(iter->blogin &&((curr_time - iter->heart_time) > 10000)) {
			close(iter->fd);
			iter->blogin = false;
			iter = peer_list.erase(iter);
		}
	}
	mutex.unlock();
}

void CPeerFdList::UpdatePeerInof(int fd, PeerInfo &peer_info)
{
	mutex.lock();
	for(std::list<PeerFDNode>::iterator
			iter = peer_list.begin();
		iter != peer_list.end(); iter++) {
		if(fd == iter->fd) {
			iter->peer_info = peer_info;
			break;
		}
	}
	mutex.unlock();
}
void CPeerFdList::DeletePeer(char *peer_name)
{
	mutex.lock();
	for(std::list<PeerFDNode>::iterator iter = peer_list.begin();
		iter != peer_list.end();	iter++) {
		if(!strcmp(iter->peer_info.username, peer_name)) {

			iter = peer_list.erase(iter);
		}
	}
	mutex.unlock();
}

void CPeerFdList::SetPeerOffline(int fd)
{
	mutex.lock();
	for(std::list<PeerFDNode>::iterator iter = peer_list.begin();
		iter != peer_list.end();	iter++) {
		if(iter->blogin && fd == iter->fd) {
			iter->blogin = false;
		}
	}
	mutex.unlock();
}
void CPeerFdList::DeletePeer(int fd)
{
	mutex.lock();
	for(std::list<PeerFDNode>::iterator iter = peer_list.begin();
		iter != peer_list.end();	iter++) {
		if(fd == iter->fd) {
			iter = peer_list.erase(iter);
		}
	}
	mutex.unlock();
}
void CPeerFdList::ClearAllPeer()
{
	mutex.lock();
	peer_list.clear();
	mutex.unlock();
}
void CPeerFdList::PrintPeers()
{
	mutex.lock();

	if (!peer_list.empty()) {
		log_info("user list information in server:");
	}
	for(std::list<PeerFDNode>::iterator
			iter = peer_list.begin();
		iter != peer_list.end(); iter++) {
		struct in_addr user_addr;
		user_addr.s_addr = iter->peer_info.ip_addr;

		char status[20];
		if (iter->blogin) {
			strcpy(status , "online");
		} else {
			strcpy(status , "offline");
		}

		log_info("username: %s ip: %s state: %s", 
				iter->peer_info.username, inet_ntoa(user_addr), status);
	}

	mutex.unlock();
}
