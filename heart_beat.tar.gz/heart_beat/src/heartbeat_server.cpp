//============================================================================
// Name        : heartbeat_server.cpp
// Author      : song
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include "Threads.h"
#include "CServer.h"
#include "Config.h"
#include <unistd.h>
using namespace std;



int main(int argc, char *argv[]) 
{
	const char config_name[] = "../config/example.conf";
		
	CServer server_demo;
	server_demo.Init(argv[0], config_name);
	server_demo.Start();

	while(1);

	return 0;
}
