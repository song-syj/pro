/*
 * CServer.h
 *
 *  Created on: Jul 23, 2014
 *      Author: song
 */

#ifndef CSERVER_H_
#define CSERVER_H_

#include "Threads.h"
#include "Socket.h"
#include "Common.h"
#include "CPeerFdList.h"
#include "log.h"
#include "CMysqlDB.h"

class CServer {
	public:
		void Start();
		void Init(const char *app, const char* config_file);
		CPeerFdList peer_list;
	private:
		static void* HeartBeatCheck(void *);
		static void* RecvProcess(void *);
		static void *ListenLoop(void *arg);

		static void UserLoginResponse(int client_fd, DataPackage *ptr_recv_pack, CServer *ptr_server);
		static void UserListResponse(int client_fd, DataPackage *ptr_recv_pack, CServer *ptr_server);
		static void HeartBeatResponse(int client_fd, DataPackage *ptr_recv_pack, CServer *ptr_server);
		static void RetransmitChatMessage(int client_fd, DataPackage *ptr_recv_pack, CServer *ptr_server);
		static void LogoutProcess(int client_fd, DataPackage *ptr_recv_pack, CServer *ptr_server);
		static void UserChatRecordsResponse(int client_fd, DataPackage *ptr_recv_pack, CServer *ptr_server);

		bool UserLoginVerify(const uint32_t uid,const char *passwd);
		bool UpdataUserLoginInfo(const uint32_t uid, const int ip_addr, PeerInfo &peer_info);
		bool AddChatRecord(const PeerInfo &src, const PeerInfo &des, const std::string &text);
		bool GetUserRecords(uint32_t uid, ChatRecordItems &list);

		CDBConnection db_conn;
		ThreadPool thread_pool;
		TCPSocket server_sock;
		Mutex *mutexs;
		Thread thread_heart_check;
		Thread thread_listen_loop;
		bool server_start;
};



#endif /* CSERVER_H_ */
