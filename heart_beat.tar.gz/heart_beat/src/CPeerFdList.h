#ifndef _CPEERFDLIST_H
#define _CPEERFDLIST_H

#include "Threads.h"
#include "Socket.h"
#include "Common.h"


class CPeerFdList {
public:
	 void AddPeer(PeerFDNode &peer_node);
	 bool GetPeer(int fd, PeerFDNode &goal_peer);
	 bool GetPeer(const char *peer_name, PeerFDNode &goal_peer);
	 void GetPeerList(std::list<PeerInfo> &user_list);
	 void SetPeerName(int fd, const char *peer_name);
	 void UpdateHeartTime(int fd, uint64_t updata_time);
	 void SetPeerOffline(int fd);
	 void HeartTimeCheck(uint64_t curr_time);
	 void UpdatePeerInof(int fd, PeerInfo &peer_info);
	 void DeletePeer(char *peer_name);
	 void DeletePeer(int fd);
	 void ClearAllPeer();
	 void PrintPeers();
private:
		std::list<PeerFDNode>peer_list;
		Mutex mutex;
};


#endif
