#include "CMysqlDB.h"
#include "log.h"
#include <stdlib.h>
#include <string.h>

void CDBConnection::Init(const char *host, int port, const char *db, const char * user, const char * passwd, const char * charset)
{
	m_host = host;
	m_port = port;
	m_db   = db;
	m_user = user;
	m_passwd = passwd;
	m_charset = charset;
}

bool CDBConnection::Connect()
{
	mysql_instance = mysql_init(NULL);
	if(mysql_instance == NULL) {
		log_crit("imysql_init error");
		return  false;
	}

	if (mysql_real_connect(mysql_instance,m_host.c_str(),
			   m_user.c_str(), m_passwd.c_str(), m_db.c_str(),
			   m_port, NULL, 0) == NULL) {
		log_crit("%s", mysql_error(mysql_instance));
		return false;
	}

	if (0 != mysql_set_character_set(mysql_instance, m_charset.c_str())) { 
		log_crit("%s",mysql_error(mysql_instance));
		return false;
	}

	return true;
}

bool CDBConnection::Reconnect()
{
	mysql_close(mysql_instance);

	mysql_instance = mysql_init(mysql_instance);
	if(mysql_instance == NULL) {
		log_crit("imysql_init error");
		return  false;
	}

	if (mysql_real_connect(mysql_instance,m_host.c_str(),
			   m_user.c_str(), m_passwd.c_str(), m_db.c_str(),
			   m_port, NULL, 0) == NULL) {
		log_crit("%s",mysql_error(mysql_instance));
		return false;
	}

	if (!mysql_set_character_set(mysql_instance, m_charset.c_str())) { 
		log_crit("%s",mysql_error(mysql_instance));
		return false;
	}

	return true;
}

bool CDBConnection::SelectQuery(const char *sql, CDBRecordSet &record_set)
{
	ScopedLock scoped_lock(op_mutex);

	if (strstr(sql, "select") == NULL) {
		log_crit("not select statement");
		return false;
	}

	if (!Ping(mysql_instance)) {
		Reconnect();
	}

	if(mysql_real_query(mysql_instance, sql, strlen(sql)) !=0) {
		log_crit("%s",mysql_error(mysql_instance));
		return false;
	}

	MYSQL_RES * ptr_res = mysql_store_result(mysql_instance);

	if (ptr_res == NULL) {
		log_crit("%s",mysql_error(mysql_instance));
		return false;
	}

	int field_num = mysql_num_fields(ptr_res);
	
	MYSQL_FIELD *ptr_field;
	std::vector<std::string> field_vect;
	while((ptr_field = mysql_fetch_field(ptr_res))) {
		field_vect.push_back(ptr_field->name);
	}

	MYSQL_ROW row_record;
	int row_index = 0;
	while((row_record = mysql_fetch_row(ptr_res))) {
		CDBRecord tmp;
		for(int i = 0; i < field_num; i++) {
			tmp[field_vect[i]] =  row_record[i];
		}
		record_set.push_back(tmp);
		row_index++;
	}

	mysql_free_result(ptr_res);

	return true;
}

bool CDBConnection::ExecuteQuery(const char *sql, int &affected_rows) 
{
	ScopedLock scoped_lock(op_mutex);

	if (!Ping(mysql_instance)) {
		Reconnect();
	}

	if(mysql_query(mysql_instance, sql) !=0) {
		log_crit("%s",mysql_error(mysql_instance));
		return false;
	}
	
	affected_rows = mysql_affected_rows(mysql_instance);

	return true;
}

size_t CDBConnection::EscapeString(char *escaped, const char *original, size_t length)
{
	return mysql_real_escape_string(mysql_instance, escaped, original, length);
}
size_t CDBConnection::EscapeString(std::string &ps, const char *original, size_t length)
{
	if (length == 0) {
		length = strlen(original);
	}
	char * escaped = new char[length * 2 + 1];
	length = mysql_real_escape_string(mysql_instance, escaped, original, length);
	ps.assign(escaped, length);

	delete [] escaped;

	return length;
}

bool CDBConnection::Ping(MYSQL *mysql)
{
	return mysql_ping(mysql) == 0;
}

void CDBConnection::Close() 
{
	return mysql_close(mysql_instance);
}

