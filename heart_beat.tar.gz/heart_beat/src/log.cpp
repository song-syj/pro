#include <stdlib.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <time.h>
#include <string.h>
#include <stdarg.h>
#include <stdio.h>
#include <unistd.h>
#include <errno.h>
#include "log.h"

#define LOGSIZE 102400

int __log_level__ = 6;
bool __log_pid__ = true;
//log dir 
static char log_dir[128] = "../log";
//module name
static char appname[32];

void init_log (const char *app, const char *dir)
{
	strncpy(appname, app, sizeof(appname)-1);
	if(dir) {
		strncpy (log_dir, dir, sizeof (log_dir) - 1);
	}
	mkdir(log_dir, 0777);
	if(access(log_dir, W_OK|X_OK) < 0)
	{
		log_error("logdir(%s): Not writable", log_dir);
	}
}

void set_log_level(int l)
{
	if(l>=0)
		__log_level__ = l > 4 ? l : 4;
}

void set_log_pid(bool b)
{
	__log_pid__ = b;
}
/**  
* @brief CConfig::write_log
* @function:writ log to file
  @param : level, loglevel
  		  filename, file name
  		  funcname, function name
  		  lineno , the line number in the file
  		  format, log format
*/

void write_log (
	int level, 
	const char *filename, 
	const char *funcname,
	int lineno,
	const char *format, ...)
{
	// save errno
	int savedErrNo = errno;
	int off = 0;
	char buf[LOGSIZE];
	char logfile[256];

	// construct prefix
	{
		struct tm tm;
		time_t now = time (NULL);
		localtime_r(&now, &tm);
		filename = basename(filename);
		unsigned int logid = __log_pid__? getpid():gettid();
		off = snprintf (buf, LOGSIZE,
				"<%d>[%02d:%02d:%02d] pid[%u]: %s(%d)[%s]: ",
				level,
				tm.tm_hour, tm.tm_min, tm.tm_sec,
			 	logid,
				filename, lineno, funcname
			);
		if(tm.tm_hour > 12)
		{
			snprintf (logfile, sizeof(logfile),
                "%s/%s_%04d%02d%02dpm.log", log_dir, appname,
                tm.tm_year + 1900, tm.tm_mon + 1, tm.tm_mday);
		}
		else
		{
			snprintf (logfile, sizeof(logfile),
                "%s/%s_%04d%02d%02dam.log", log_dir, appname,
                tm.tm_year + 1900, tm.tm_mon + 1, tm.tm_mday);
		}	
	}
	// formatted message
	{
		va_list ap;
		va_start(ap, format);
		// restore errno
		errno = savedErrNo;
		off += vsnprintf(buf+off, LOGSIZE-off-1, format, ap);
		va_end(ap);
	}
    
  	if((off+1) >= LOGSIZE)
       {
            off = LOGSIZE-1;
            buf[off] = '\0';
        }
	else
	{
            if(buf[off-1]!='\n')
		buf[off++] = '\n';
	}		
	
    if (-1 == level)
    {
	    fwrite(buf+3, 1, off-3, stderr);
    }

	if(appname[0])
	{
		int fd = open (logfile, O_CREAT | O_LARGEFILE | O_APPEND |O_WRONLY, 0644);
		if (fd >= 0)
		{
			write(fd, buf, off);
			close (fd);
		}
	}
}


