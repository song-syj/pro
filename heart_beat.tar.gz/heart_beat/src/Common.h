#ifndef _COMMON_H
#define _COMMON_H

#include<stdint.h>
#include<unistd.h>
#include<iostream>
#include<netinet/in.h>
#include<list>
#include<vector>
#include"Threads.h"

#define MAX_PASSWD_LEN (20)
#define MAX_USERNAME_LEN (20)
#define MAX_USERLIST_SIZE (20)
#define MAX_CHAT_MESSAGE (50)
#define TIME_LEN (20)
#define MAX_CHAT_ITEM_SIZE (50)

#pragma pack(4)

typedef struct LoginInfo {
    uint32_t user_id;
    char passwd[MAX_PASSWD_LEN];
}LoginInfo;


typedef struct PeerInfo {
	char username[MAX_USERNAME_LEN];
	uint32_t user_id;
	uint32_t ip_addr;
	uint16_t port;
}PeerInfo;

// for server manage user'information
typedef struct PeerFDNode {
	int fd;
	bool blogin;
	uint64_t heart_time;
	PeerInfo peer_info;
}PeerFDNode;


typedef struct PeerListInfo {
	int32_t size;
	PeerInfo peerlist[MAX_USERLIST_SIZE];
}PeerListInfo;


typedef struct ChatMessage {
	PeerInfo src;
	PeerInfo des;
	char text[MAX_CHAT_MESSAGE];
}ChatMessage;


typedef struct ChatRecord {
	uint32_t src_id;
	uint32_t des_id;
	char src_name[MAX_USERNAME_LEN];
	char des_name[MAX_USERNAME_LEN];
	char text[MAX_CHAT_MESSAGE];
	char time[TIME_LEN];
}ChatRecord;

typedef struct ChatRecordSet {
	int size;
	ChatRecord chat_items[MAX_CHAT_ITEM_SIZE];
}ChatRecordSet ;


typedef std::vector<ChatRecord>ChatRecordItems;


typedef struct DataPackage {
    uint32_t type;
    int32_t length;
    uint8_t data[0];
}DataPackage;

#pragma pack()

class CPeerList {
public:
	void AddPeer(PeerInfo &peer_info)
	{
		mutex.lock();
		peer_list.push_back(peer_info);
		mutex.unlock();
	}

	bool GetPeer(const char *peer_name, PeerInfo &goal_peer)
	{
		mutex.lock();
		bool find = false;
		for(std::list<PeerInfo>::iterator
				iter = peer_list.begin();
				iter != peer_list.end(); iter++) {
			if(!strcmp(iter->username, peer_name)) {
				 goal_peer = *iter;
				 find = true;
				 break;
			}
		}
		mutex.unlock();

		return find;
	}

	void DeletePeer(char *peer_name)
	{
		mutex.lock();
		for(std::list<PeerInfo>::iterator iter = peer_list.begin();
				iter != peer_list.end();	iter++) {
			if(!strcmp(iter->username, peer_name)) {

				iter = peer_list.erase(iter);
				mutex.unlock();
				return;
			}
		}
		mutex.unlock();
	}
	void ClearAllPeer()
	{
		mutex.lock();
		peer_list.clear();
		mutex.unlock();
	}
	void PrintPeers()
	{
		mutex.lock();
		for(std::list<PeerInfo>::iterator
				iter = peer_list.begin();
				iter != peer_list.end(); iter++) {
			struct in_addr peer_addr;
			peer_addr.s_addr = iter->ip_addr;
			std::cout << "username:"
					<< iter->username 
					<< "(" << iter->user_id << ") "
					<< inet_ntoa(peer_addr)
					<< std::endl;
		}
		mutex.unlock();
	}
private:
	std::list<PeerInfo>peer_list;
	Mutex mutex;
};

class ChatRecordList  {
public:
	ChatRecordList() {}

	ChatRecordList (ChatRecordList &rlist)
	{
		record_list = rlist.record_list;
	}

	void AddItem(ChatRecord &record_item)
	{
		record_list.push_back(record_item);
	}

	void ClearAllItem()
	{
		record_list.clear();
	}

	void PrintItems()
	{
		std::cout << "--------------Chat Record-----------------" << std::endl;
		for(std::vector<ChatRecord>::iterator
				iter = record_list.begin();
				iter != record_list.end(); iter++) {
			std::cout  << "Time : " << iter->time <<std::endl 
				<< "From " << iter->src_name 
				<< "(" << iter->src_id << ")"
				<<" to " << iter->des_name 
				<< "(" << iter->des_id << ")" << std::endl;
			std::cout << "Content: " << iter->text << std::endl;
			std::cout << std::endl;
		}
		std::cout << "--------------End Record------------------" << std::endl;
	}
	
	void ConvertoRecordSet(ChatRecordSet &record_set)
	{
		record_set.size = record_list.size();
		int i = 0;
		for (std::vector<ChatRecord>::iterator
				iter = record_list.begin(); 
				iter != record_list.end(); iter++) {
			record_set.chat_items[i++] = *iter;
		}
	}

private:
	std::vector<ChatRecord>record_list;
};

#endif // _COMMON_H
