#ifndef _DAEMON_H
#define _DAEMON_H

int daemon_init(int nochdir, int noclose);

#endif
