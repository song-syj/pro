#include "Socket.h"
#include "Timerval.h"
#include<stdio.h>
#include<stdlib.h>
#include <sys/types.h>
#include<netinet/in.h>
#include<sys/socket.h>
#include <unistd.h>
#include <fcntl.h>
#include "log.h"


static ssize_t readn(int fd, void *vptr, ssize_t n);
static ssize_t	writen(int fd,const void *vptr, ssize_t n);

TCPSocket::TCPSocket()
{
	sockfd = socket(AF_INET, SOCK_STREAM, 0);
	if (sockfd < 0) {
		log_crit("socket() failed");
		throw SocketError();
	}
}

void TCPSocket::Create()
{
    sockfd = socket(AF_INET, SOCK_STREAM, 0);
	if (sockfd < 0) {
		log_crit("create sock() failed");
		throw SocketError();
	}
}

void TCPSocket::NonBlocking()
{
	if (fcntl(sockfd,F_SETFL,O_NONBLOCK) < 0) {
		log_crit("set socket non block");
		throw SocketError();
	}
}

void TCPSocket::NonBlocking(int fd)
{
	if (fcntl(fd,F_SETFL,O_NONBLOCK) < 0) {
		log_crit("set socket non block");
		throw SocketError();
	}
}

void TCPSocket::Blocking()
{
	if (fcntl(sockfd,F_SETFL,0) < 0) {
		log_crit("set socket non block");
		throw SocketError();
	}
}

void TCPSocket::Blocking(int fd)
{
	if (fcntl(fd,F_SETFL,0) < 0) {
		log_crit("set socket non block");
		throw SocketError();
	}
}

bool TCPSocket::Connect(const char *server_ip, const uint16_t server_port)
{
	bzero(&servaddr, sizeof(servaddr));
	servaddr.sin_family = AF_INET;
	servaddr.sin_port = htons(server_port);
	inet_pton(AF_INET, server_ip, &servaddr.sin_addr);

	int ret = connect(sockfd, (SA *) &servaddr, sizeof(servaddr));
	if(ret < 0) {
		return false;
	} else {
		return true;
	}
}

bool TCPSocket::Connect(struct sockaddr_in & server_addr)
{
	int ret = connect(sockfd, (SA *) &server_addr, sizeof(server_addr));
	if(ret < 0) {
		return false;
	} else {
		return true;
	}
}

bool TCPSocket::Reconnect()
{
	int ret = connect(sockfd, (SA *) &servaddr, sizeof(servaddr));
	if(ret < 0) {
		return false;
	} else {
		return true;
	}
}


static ssize_t readn(int fd, void *vptr, ssize_t n)
{
	ssize_t	nleft;
	ssize_t	nread;
	char	*ptr;

	ptr = (char *)vptr;
	nleft = n;
	while (nleft > 0) {
		if ( (nread = read(fd, ptr, nleft)) < 0) {
			if (errno == EINTR)
				nread = 0;		/* and call read() again */
			else
				return(-1);
		} else if (nread == 0)
			break;				/* EOF */

		nleft -= nread;
		ptr   += nread;
	}
	return(n - nleft);		/* return >= 0 */
}

ssize_t TCPSocket::Readn(int fd, void *ptr, ssize_t nbytes)
{
	return readn(fd, ptr, nbytes);
}

ssize_t TCPSocket::Readn(void *ptr, ssize_t nbytes)
{

	return readn(sockfd, ptr, nbytes);
}

ssize_t TCPSocket::Writen(const void *ptr, ssize_t nbytes)
{
	return writen(sockfd, ptr, nbytes);
	
}

ssize_t TCPSocket::Writen(int fd, const void *ptr, ssize_t nbytes)
{
	return writen(fd, ptr, nbytes);
}

static ssize_t	writen(int fd,const void *vptr, ssize_t n)
{
	ssize_t		nleft;
	ssize_t		nwritten;
	const char	*ptr;

	ptr = static_cast<const char *>(vptr);
	nleft = n;
	while (nleft > 0) {
		if ( (nwritten = write(fd, ptr, nleft)) <= 0) {
			if (nwritten < 0 && errno == EINTR)
				nwritten = 0;		/* and call write() again */
			else
				return(-1);			/* error */
		}

		nleft -= nwritten;
		ptr   += nwritten;
	}

	return(n);
}

bool TCPSocket::Bind(struct sockaddr_in & server_addr, bool reuse)
{
	servaddr = server_addr;
	if (reuse) {
		const int on = 1;
		if (setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR, &on, sizeof(on)) < 0)
		{
			return false;
		}
	}

	if (bind(sockfd, (SA *)&server_addr, sizeof(server_addr)) < 0) {
		return false;
	} else {
		return true;
	}
}

bool TCPSocket::Bind(const char *server_ip, uint16_t server_port, bool reuse)
{
	bzero(&servaddr, sizeof(servaddr));
	servaddr.sin_family = AF_INET;
	servaddr.sin_port = htons(server_port);
	servaddr.sin_family = AF_INET;
	if(server_ip == NULL || !strcmp(server_ip, ""))
		servaddr.sin_addr.s_addr = htonl (INADDR_ANY);
	else
		servaddr.sin_addr.s_addr = inet_addr(server_ip);

	if (reuse) {
		const int on = 1;
		if (setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR, &on, sizeof(on)) < 0)
		{
			return false;
		}
	}

	if (bind(sockfd, (SA *)&servaddr, sizeof(servaddr)) < 0) {
		return false;
	} else {
		return true;
	}
}

bool TCPSocket::Listen(int backlog)
{
	char	*ptr;

	if ( (ptr = getenv("LISTENQ")) != NULL)
		backlog = atoi(ptr);


	if (listen(sockfd, backlog) < 0) {
		return false;
	} else {
		return true;
	}
}

int TCPSocket::Accept(struct sockaddr *sa, socklen_t *salenptr)
{
	int	n;

again:
	if ((n = accept(sockfd, sa, salenptr)) < 0) {
#ifdef	EPROTO
		if (errno == EPROTO || errno == ECONNABORTED)
#else
			if (errno == ECONNABORTED)
#endif
				goto again;
			else {
				log_crit("accept() failed");
				throw SocketError();
			}
	}
	return(n);
}


bool TCPSocket::Close()
{
	if (close(sockfd) == -1) {
		return false;
	} else {
		return true;
	}
}

struct sockaddr_in TCPSocket::GetLocalAddr()
{
	struct sockaddr_in addr;
	socklen_t len = sizeof(addr);
	if (getsockname(sockfd, (struct sockaddr *)&addr, &len) < 0)
	{
		log_crit("get local addrr error");
		throw SocketError();
	}

	return addr;
}
struct sockaddr_in TCPSocket::GetRemoteAddr(int fd)
{
	struct sockaddr_in addr;
	socklen_t len = sizeof(addr);

	if (getpeername(fd, (struct sockaddr *)&addr, &len) < 0)
	{
		log_crit("get remote addrr error");
		throw SocketError();
	}

	return addr;
}


int  TCPSocket::Recv(int fd, char *ptr, int length, uint32_t timeout)
{
	Timeval wait_time(timeout);
	int nleft = length;
	int nread;

	while (!wait_time.passed() && nleft > 0) {
		if ( (nread = recv(fd, ptr, nleft, MSG_DONTWAIT)) <= 0) {
			if (nread < 0) {
				if (errno == EINTR
						|| errno == EAGAIN
						|| errno == EWOULDBLOCK) {
					nread = 0;
					/* and call readn() again */
				}
				else
					break;			/* error */
			}
		} else if (nread == 0) {
			break;
		}

		nleft -= nread;
		ptr   += nread;
	}

	return (length - nleft);
}

int TCPSocket::Send(int fd, char *ptr, int length, uint32_t timeout)
{
	Timeval wait_time(timeout);
	int nleft = length;
	int nwrite;

	while (!wait_time.passed() && nleft > 0) {
		if ( (nwrite = send(fd, ptr, nleft, MSG_DONTWAIT)) <= 0) {
			if (nwrite < 0) {
				if (errno == EINTR
						|| errno == EAGAIN
						|| errno == EWOULDBLOCK) {
					nwrite = 0;
					/* and call readn() again */
				}
				else
					break;			/* error */
			}
		}

		nleft -= nwrite;
		ptr   += nwrite;
	}

	return (length - nleft);
}
