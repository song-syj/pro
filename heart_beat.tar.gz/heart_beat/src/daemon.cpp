#include<unistd.h>
#include<sys/stat.h>
#include<signal.h>
#include<sys/wait.h>
#include<error.h>
#include<stdio.h>
#include<fcntl.h>
#include<string.h>
#include<stdlib.h>
#include "daemon.h"

int daemon_init(int nochdir, int noclose)
{
	switch(fork()) {
		case 0:
			break;
		case -1:
			return -1;
		default:
			exit(0);
	}
	
	if(setsid() < 0)
		return -1;

	signal(SIGINT, SIG_IGN);
	signal(SIGHUP, SIG_IGN);
	signal(SIGQUIT, SIG_IGN);
	signal(SIGPIPE, SIG_IGN);
	signal(SIGTTOU, SIG_IGN);
	signal(SIGTTIN, SIG_IGN);
	signal(SIGCHLD, SIG_IGN);
	signal(SIGTERM,SIG_IGN);

	umask(0);

	switch(fork()) {
		case 0:
			break;
		case -1:
			return -1;
		default:
			exit(0);
	}
	
	if (!nochdir) {
		chdir("/");
	}
	
	if (!noclose) {
		int fdlimit = sysconf(_SC_OPEN_MAX);
		int fd = 0;
		while(fd < fdlimit) {
			close(fd++);
		}

		open("/dev/null", O_RDONLY);
		dup(0);
		dup(0);
	}
	
	return 0;
}
