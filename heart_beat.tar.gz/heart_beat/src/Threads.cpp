/*
 * Threads.cpp
 *
 *  Created on: Jul 25, 2014
 *      Author: song
 */
#include "Threads.h"
#include <iostream>

bool ThreadPool::Init()
{
	pool_state = POOL_START;
	for(int i= 0; i < pool_size; i ++) {
		Thread *ptr_thread = new Thread;
		ptr_thread->Start(ExectueThread, this);
		threads_vect.push_back(ptr_thread);
	}

	return true;
}

bool ThreadPool::Destroy()
{
	pool_state = POOL_STOP;
	task_cond_var.Broadcast();
	void *res;
	for (int i = 0; i < pool_size; i++) {
		threads_vect[i]->Join(&res);
		delete threads_vect[i];
		std::cout << "destory thead" << std::endl;
	}
	std::cout << "destory thead pool" << std::endl;
	return true;
}

bool ThreadPool::AddTask(Task *ptr_task)
{
	task_mutex.lock();
	task_deque.push_back(ptr_task);
	task_cond_var.Signal();
	task_mutex.unlock();

	return true;
}

void *ThreadPool::ExectueThread( void *arg)
{
	ThreadPool *ptr_pool = (ThreadPool *)arg;

	while(true) {
		ptr_pool->task_mutex.lock();

		while(ptr_pool->pool_state != ThreadPool::POOL_STOP
				&& ptr_pool->task_deque.empty()) {
			ptr_pool->task_cond_var.Wait(ptr_pool->task_mutex);
		}

		if (ptr_pool->pool_state == ThreadPool::POOL_STOP) {
			ptr_pool->task_mutex.unlock();
			return NULL;
		}

		Task *ptr_task = ptr_pool->task_deque.front();
		ptr_pool->task_deque.pop_front();
		ptr_pool->task_mutex.unlock();

		ptr_task->Run();

		delete ptr_task;
	}

	return NULL;
}



