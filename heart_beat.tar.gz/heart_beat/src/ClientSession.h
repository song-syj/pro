#ifndef _CLIENT_SESSION_H
#define _CLIENT_SESSION_H

#include "Socket.h"
#include "MessageUnit.h"
#include "Common.h"
//#include "Timer.h"

class ClientSession
{
public:
	bool Connect(const char * server_ip, const uint16_t server_port);
	bool Reconnect();
	bool Run();
	bool Close();
	void UserInterface();

	void PrintLocalUserInfo();

	bool Login(const uint32_t uid,const char *passwd);
	bool ReLogin();
	bool Logout();

private:
	bool SendMessage(const char* peername, const char * send_text);
	bool GetUserList();
	bool GetChatRecord();

	void PrintChatRecords();
	void PrintUserList();

	bool IsExit() { return to_exit;}
	void Exit() ;

	static void* HeartBeatCheck(void *);
	static void* RecvProcess(void *);
	void WritePackage(DataPackage &data_pack);
	DataPackage* ReadPackage();

	std::string login_name;
	CPeerList online_peers;
	ChatRecordList chat_record_list;
	TCPSocket local_socket;
	PeerInfo local_info;
    std::string local_passwd;
	Thread recv_thread;
	Thread heartbeat_thread;
	volatile uint64_t heart_last_time;

	volatile bool login_success;
	volatile bool login_fail;
	volatile bool logout_success;
	volatile bool msg_send_success;
	volatile bool userlist_cmp;
	volatile bool chat_records_cmp;
	volatile bool heartbeat_start;
	volatile bool connect_success;
	volatile bool to_exit;
};

#endif
