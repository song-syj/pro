#include<unistd.h>
#include<sys/stat.h>
#include<signal.h>
#include<sys/wait.h>
#include<error.h>
#include<stdio.h>
#include<fcntl.h>
#include<string.h>
#include<stdlib.h>
#include "daemon.h"
#include "log.h"
#include "Config.h"


int main(int argc, char *argv[])
{
	daemon_init(1, 0);
	char server_app[] = "SERVER";
	const char config_name[] = "../config/example.conf";
	int log_level;

	Config conf_set(config_name);
	log_level = conf_set.Read("log_level", 6);

	// init log 
	init_log(server_app, "../log");
	set_log_level(log_level);

	int setup_num = 100;
	int status;

	argv[0] = server_app;
	while(setup_num--) {
		log_crit("startup server_app ");
		pid_t pid;
		pid = fork();
		if (pid == 0) {
			if(execv(server_app, argv) < 0) {
				log_crit("execv server_app error");
				exit(0);
			}
		} else if (pid < 0) {
				log_crit("create server_app process error");
				exit(0);
		}

		wait(&status);
		if(WIFEXITED(status))
			log_warning("server normal termination, exit status = %d\n", WEXITSTATUS(status));
		else if (WIFSIGNALED(status)) 
			log_warning("server abnormal termination, signal number = %d\n", WTERMSIG(status));
		else if (WIFSTOPPED(status))
			log_warning("server stopped, signal bumber = %d\n", WSTOPSIG(status));
		else
			log_warning("server stopped in other reason");
	}

	log_crit("server corrupt!");

	return 0;
}
