#ifndef SOCKET_H_
#define SOCKET_H_

#include <arpa/inet.h>
#include <netdb.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <sys/un.h>
#include <errno.h>
#include <list>
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <stdint.h>
#include "log.h"

class TCPSocket {
public:
	typedef struct sockaddr SA;

	TCPSocket();
    void Create();
    void NonBlocking();
    void Blocking();
    static void  NonBlocking(int fd);
    static void  Blocking(int fd);
    static int Recv(int fd, char *buff, int length, uint32_t timeout);
    static int Send(int fd, char *buff, int length, uint32_t timeout);
	ssize_t Readn(void *vptr, ssize_t n);
	static ssize_t Readn(int fd, void *vptr, ssize_t n);

	ssize_t Writen(const void *vptr, ssize_t n);
	static ssize_t Writen(int fd,const void *vptr, ssize_t n);

	bool Bind(struct sockaddr_in & server_addr, bool reuse = false);
	bool Bind(const char *server_ip =NULL, uint16_t server_port = 8080, bool reuse = false);
	bool Close();
	bool Connect(const char *server_ip, const uint16_t server_port);
	bool Connect(struct sockaddr_in & server_addr);
	bool Reconnect();
	bool Listen(int backlog);
	int Accept(struct sockaddr *sa, socklen_t *salenptr);
	struct sockaddr_in GetLocalAddr();
	static struct sockaddr_in GetRemoteAddr(int fd);
	int GetSocketFd() { return sockfd ;}
private:
	int sockfd;
	struct sockaddr_in servaddr;
};

class SocketError {};

#endif /* SOCKET_H_ */
