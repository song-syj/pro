//============================================================================
// Name        : hearbeat.cpp
// Author      : 
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include <string>
#include <unistd.h>
#include "ClientSession.h"
#include "Config.h"

using namespace std;

int main(int argc, char *argv[0]) {
	ClientSession client;
	string server_ip;
	uint16_t port;
	int log_level;
	Config conf_set("../config/example.conf");

	port = conf_set.Read("server_port", 8080);
	server_ip = conf_set.Read("ip_addr", server_ip);
	log_level = conf_set.Read("log_level", 7);
	
	// init log 
	init_log(argv[0], "../log");
	set_log_level(log_level);

	if (client.Connect(server_ip.c_str(), port) == false) {
		cout << "connect fail!" << endl;
		sleep(2);
		exit(1);
	}
	client.Run();

	uint32_t user_id;
	string passwd;
	cout << "Please input your login account:";
	cin >> user_id;
	cout << "Please input your passwd:";
	cin >> passwd;

	//	strcpy(username, "song");
	if (client.Login(user_id, passwd.c_str())) {
		cout << "login success" << endl;
		client.PrintLocalUserInfo();
	} else {
		cout << "login fail" << endl;
		exit(1);
	}

	client.UserInterface();

	return 0;
}
