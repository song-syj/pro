#include <iostream>
#include <unistd.h>
#include <sys/time.h>
#include "ClientSession.h"

#define HEAR_BEAT_TIMERVAL 5

bool ClientSession::Connect(const char * server_ip, const uint16_t server_port)
{
	bool res = local_socket.Connect(server_ip, server_port);
	if (res == true) {
		connect_success = true;
	}

	return res;
}


bool ClientSession::Run()
{
	to_exit = false;
	recv_thread.Start(RecvProcess, this);

	return true;
}

void ClientSession::UserInterface()
{
	std::cout << "\nCommands are:"
		"\n\t(1)getu ----- get online user list"
		"\n\t(2)getr ----- get user chat record"
		"\n\t(3)send ----- send message to other user"
		"\n\t(4)exit ----- exit the process\n\n";

	std::string user_input;
	std::cin.ignore(1024,'\n');
	while(!IsExit()) {
		std::cout << ">>";
		getline(std::cin,user_input);
		if (user_input.empty()) continue;
		//process the user input cmd
		int word_start = user_input.find_first_not_of(' ', 0);
		int word_end = user_input.find_first_of(' ', word_start);
		int next_start = user_input.find_first_not_of(' ', word_end);
		std::string cmd = user_input.substr(word_start, word_end- word_start);

		if (cmd == "getu") {
			if(GetUserList()) {
				PrintUserList();
			} else {
				std::cout << "get user list from server error" << std::endl;
			}
		} else if (cmd == "getr") {
			if(!GetChatRecord()) {
				std::cout << "get user chat records from server error" << std::endl;
			} else {
				PrintChatRecords();
		 	}

		} else if (cmd == "send") {
			word_start = next_start;
			if (word_start == -1) {
				std::cout << "send cmd need second arg(name)" << std::endl;
				continue;
			}
			std::string remain = user_input.substr(word_start);
			word_start = 0;
			word_end = remain.find_first_of(' ', word_start);
			next_start = remain.find_first_not_of(' ', word_end);
			std::string peername = remain.substr(word_start, word_end);

			if(next_start == -1) {
				std::cout << "send message can't be empty!" << std::endl;
				continue;
			}
			std::string text = remain.substr(next_start);

			bool ret = SendMessage(peername.c_str(), text.c_str());
			if (ret == false) {
				std::cout << "send message fail!" << std::endl;
			} else {
				std::cout << "send message success!" << std::endl;
			}

		} else if (cmd == "exit"){
			Logout();
			std::cout << "client exit" << std::endl;
			Exit();

			std::cout << "exit client!";
		} else {
			std::cout << "can't recognize cmd ";
		}
		std::cout << std::endl;
	}

	std::cout << "client exit" << std::endl;
}


bool ClientSession::Reconnect()
{
	local_socket.Close();
	local_socket.Create();

	int retry = 3;
	while(retry--) {
		std::cout << "reconect server" << std::endl;
		bool ret = local_socket.Reconnect();
		if (ret == true) {
			return true;
		}

		sleep(1000);
	}
	local_socket.Close();

	return false;
}

bool ClientSession::Close()
{
	return local_socket.Close();
}

void ClientSession::WritePackage(DataPackage &data_pack)
{
	if(local_socket.Writen(&data_pack, sizeof(data_pack)+data_pack.length) == 0) {
		local_socket.Close();
	}
}

DataPackage * ClientSession::ReadPackage()
{
	DataPackage head;
	int ret = local_socket.Readn(&head, sizeof(head));
	if (ret == 0) {
		local_socket.Close();
		connect_success = false;
		return NULL;
	}

	if (ret < 0) {
		return NULL;
	}

	if (head.length > 10240) {
		std::cout << "read package heead length too large" << std::endl;
		return NULL;
	}

	DataPackage *ptr_pack = (DataPackage *)malloc(sizeof(DataPackage) + head.length);
	*ptr_pack = head;
	if (ptr_pack == NULL) {
		perror("malloc DataPackage fail!");
	    return NULL;
	}
	
	if (ptr_pack->length != 0) {
		ret = local_socket.Readn(ptr_pack->data, ptr_pack->length);
		if (ret == 0) {
			local_socket.Close();
			connect_success = false;
			free(ptr_pack);
			return NULL;
		}

		if (ret < 0 || ret != ptr_pack->length) {
			free(ptr_pack);
			return NULL;
		}
	}

	return ptr_pack;
}

bool ClientSession::ReLogin()
{
	LoginRequestMessage login_msg(local_info.user_id, local_passwd.c_str());
	DataPackage *pdata = login_msg.assemble();

	login_success = false;
	for (int i = 0; i < 5; i++) {
		WritePackage(*pdata);
		for (int j = 0; j < 10; j++) {
			if (login_success == true)
			{
				free(pdata);
				// start heartbeat check
				struct timeval tv;
				gettimeofday(&tv, NULL);
				uint64_t curr_time = tv.tv_sec * 1000 + tv.tv_usec/1000;
				heart_last_time = curr_time;
				heartbeat_thread.Start(HeartBeatCheck, this);

				return true;
			}
			usleep(100000);
		}
	}

	free(pdata);
	return false;
}
bool ClientSession::Login(const uint32_t user_id, const char *passwd)
{
	LoginRequestMessage login_msg(user_id, passwd);
	DataPackage *pdata = login_msg.assemble();

	login_success = false;
	login_fail = false;
	for (int i = 0; i < 5; i++) {
		WritePackage(*pdata);
		for (int j = 0; j < 10; j++) {
			if (login_success == true)
			{
				free(pdata);
				// store local user information
				local_passwd = passwd;
				/*struct sockaddr_in local_addr = local_socket.GetLocalAddr();
				local_info.ip_addr = local_addr.sin_addr.s_addr;
				local_info.port = local_addr.sin_port;
				local_info.user_id = user_id;*/
				//strcpy(local_info.username, username);

				// start heartbeat check
				struct timeval tv;
				gettimeofday(&tv, NULL);
				uint64_t curr_time = tv.tv_sec * 1000 + tv.tv_usec/1000;
				heart_last_time = curr_time;
				heartbeat_thread.Start(HeartBeatCheck, this);

				return true;
			}
			if (login_fail == true) {
				free(pdata);
				return false;
			}
			usleep(100000);
		}
	}

	free(pdata);
	return false;
}

bool ClientSession::Logout()
{
	LogoutRequestMessage logout_req = LogoutRequestMessage();

	DataPackage *pdata = logout_req.assemble();
	WritePackage(*pdata);
	free(pdata);

	return true;
}

void ClientSession::Exit()
{
	connect_success =  false;
	to_exit = true;
	Close();
	exit(1);
}

bool ClientSession::SendMessage(const char* peername, const char * send_text)
{
	PeerInfo des_peer;
	if(online_peers.GetPeer(peername, des_peer) == false) {
		return false;
	}

	std::string text = send_text;
	UserChatMessage chat_msg = UserChatMessage(local_info,des_peer, text);

	DataPackage *pdata = chat_msg.assemble();
	msg_send_success = false;
	for (int i = 0; i < 5; i++) {
		WritePackage(*pdata);
		for (int j = 0; j < 3; j++) {
			if (msg_send_success == true) {
				free(pdata);
				return true;
			}
			usleep(100000);
		}
	}

	free(pdata);
	return false;
}

bool ClientSession::GetChatRecord()
{
	UserChatRecordRequestMessage user_chat_record_req;
	DataPackage *pdata = user_chat_record_req.assemble();
	if (pdata == NULL) {
		return false;
	}

	chat_record_list.ClearAllItem();
	chat_records_cmp = false;

	for (int i = 0; i < 5; i++) {
		WritePackage(*pdata);
		for (int j = 0; j < 10; j++) {
			if (chat_records_cmp == true) {
				free(pdata);
				return true;
			}
			usleep(100000);
		}
	}

	free(pdata);

	return false;
}

bool ClientSession::GetUserList()
{
	UserListRequestMessage userlist_req;
	DataPackage *pdata = userlist_req.assemble();

	online_peers.ClearAllPeer();
	userlist_cmp = false;

	for (int i = 0; i < 5; i++) {
		WritePackage(*pdata);
		for (int j = 0; j < 10; j++) {
			if (userlist_cmp == true) {
				free(pdata);
				return true;
			}
			usleep(100000);
		}
	}

	free(pdata);

	return false;
}

void ClientSession::PrintChatRecords()
{
	chat_record_list.PrintItems();
}

void ClientSession::PrintUserList()
{
	online_peers.PrintPeers();
}

void ClientSession::PrintLocalUserInfo()
{
	struct in_addr user_addr;
	user_addr.s_addr = local_info.ip_addr;

	std::cout << std::endl;
	std::cout << "-------------Local User Information -----------" << std::endl;
	std::cout << "user_name : " << local_info.username << std::endl;
	std::cout << "user_id : " << local_info.user_id << std::endl;
	std::cout << "ip_address: " << inet_ntoa(user_addr) << std::endl;
    std:: cout << "port: "<<local_info.port << std::endl;
	std::cout << "-----------------------------------------------" << std::endl;
}

void * ClientSession::RecvProcess(void *arg)
{
	ClientSession *ptr_client = (ClientSession *)arg;

	while(//std::cout << ptr_client->connect_success << std::endl,
			ptr_client->connect_success) {
		DataPackage *ptr_recv_pack = ptr_client->ReadPackage();
		if (ptr_recv_pack == NULL) {
			usleep(100000);
		   	continue;
		}

		switch((MessageUnit::MessageType)(ptr_recv_pack->type)) {
			case MessageUnit::USER_LOGIN_SUCCESS: 
				{
					LoginSucessMessage login_succ_msg;
					login_succ_msg.parse(*ptr_recv_pack);
					ptr_client->local_info = login_succ_msg.GetPeerInfo();
					ptr_client->login_success = true;
					break;
				}
			case MessageUnit::USER_LOGIN_FAIL: 
				{
					ptr_client->login_fail = true;
					break;
				}

			case MessageUnit::USER_LIST_ACK: 
				{
					std::cout << "recv user lsit ack" << std::endl;
					UserListAckMessage userlist_ack_msg;
					userlist_ack_msg.parse(*ptr_recv_pack);
					std::list<PeerInfo> &plist = userlist_ack_msg.peer_list;
					for(std::list<PeerInfo>::iterator
							iter = plist.begin();
							iter != plist.end(); iter++) {
						ptr_client->online_peers.AddPeer(*iter);
					}

					break;
				}
			case MessageUnit::USER_CHAT_RECORDS_ACK:
				{
					std::cout << "recv chat record ack" << std::endl;
					UserChatRecordAckMessage chat_record_ack;
					chat_record_ack.parse(*ptr_recv_pack);

					for (std::vector<ChatRecord>::iterator
							iter = chat_record_ack.records.begin();
							iter != chat_record_ack.records.end();iter++) {
						ptr_client->chat_record_list.AddItem(*iter);
					}

					break;
				}

			case MessageUnit::USER_LIST_COMPLETE: 
				{
					ptr_client->userlist_cmp = true;
					break;
				}
			case MessageUnit::USER_CHAT_RECORDS_COMPLETE:
				{
					ptr_client->chat_records_cmp = true;
					break;
				}
			case MessageUnit::HEART_BEAT_ACK: 
				{
					struct timeval tv;
					gettimeofday(&tv, NULL);
					ptr_client->heart_last_time = tv.tv_sec * 1000 + tv.tv_usec / 1000;
//					std::cout << "recieve heartbeat package:" << ptr_client->heart_last_time <<std::endl;
					break;
				}
			case MessageUnit::USER_CHAR_MESSAGE :
				{
					UserChatMessage chat_msg; 
					chat_msg.parse(*ptr_recv_pack);
					PeerInfo src_info = chat_msg.GetSrcPeer();
					struct in_addr peer_addr;
					peer_addr.s_addr = src_info.ip_addr;

					std::cout << "Receive message from:"
						<< src_info.username <<" "
					   <<inet_ntoa(peer_addr)<<std::endl;
					std::cout << "Content: " << chat_msg.GetChatContent() << std::endl;

				} break;
			case MessageUnit::USER_MESSAGE_RECV_ACK: 
				{
					ptr_client->msg_send_success = true;
					break;
				}
			case MessageUnit::USER_MESSAGE_RECV_FAIL: 
				{
					ptr_client->msg_send_success = false;
					break;
				}
			default:
				break;
		}

		free(ptr_recv_pack);
	}
	//std::cout << "Recv Thread exit" << std::endl;

	return (void *)0;
}

void * ClientSession::HeartBeatCheck(void *arg)
{
	ClientSession *ptr_client = (ClientSession *)arg;
	struct timeval tv;
	uint64_t curr_time;

	while(!ptr_client->to_exit) {
		gettimeofday(&tv, NULL);
		curr_time = tv.tv_sec * 1000 + tv.tv_usec/1000;
		// std::cout << "check heart time:"<< curr_time << std::endl;
		// std::cout << "local time:" << ptr_client->heart_last_time << std::endl;

		if ((curr_time - ptr_client->heart_last_time) > 1000 * 2 *HEAR_BEAT_TIMERVAL) {
			std::cout << "disconnect to server" << std::endl;
			ptr_client->connect_success = false;
			ptr_client->recv_thread.Join();

			std::cout << "try to reconnect to server" << std::endl;
			if (ptr_client->Reconnect()) {

				ptr_client->connect_success = true;
				ptr_client->recv_thread.Start(RecvProcess, ptr_client);
				if(ptr_client->ReLogin()) {
					std::cout << "reconnect success " << std::endl;
					continue;
				}
			}
			ptr_client->connect_success = false;
			ptr_client->to_exit = true;
			std::cout << "fail to reconnect to server" << std::endl;
		} else {
			HeartBeatQuery heart_query;
			DataPackage *ptr_recv_pack = heart_query.assemble();
			ptr_client->WritePackage(*ptr_recv_pack);
			free(ptr_recv_pack);
		}

		sleep(5);
	}

	//std::cout << "heartbeat thread exit" << std::endl;

	return (void *)0;
}


