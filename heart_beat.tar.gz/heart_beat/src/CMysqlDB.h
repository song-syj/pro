#ifndef _CMYSQLDB_H
#define _CMYSQLDB_H

#include "Threads.h"
#include "mysql.h"
#include <string>
#include <vector>
#include <map>

typedef std::map<std::string,std::string> CDBRecord;
typedef std::vector<CDBRecord > CDBRecordSet;

class CDBConnection {
public:
	CDBConnection () :mysql_instance(NULL) {}

	void Init(const char *host, int port, const char *db,
		   	const char * user, const char * passwd, const char * charset);
	bool Connect();
	bool SelectQuery(const char *sql, CDBRecordSet &record_set);
	bool ExecuteQuery(const char *sql, int &affect_rows);
	size_t EscapeString(char *escaped, const char *original, size_t length);
	size_t EscapeString(std::string &ps, const char *original, size_t length);
	void Close();
private:
	static const int MAX_SQL_LEN = 300;
	bool Ping(MYSQL *mysql);
	bool Reconnect();
	Mutex op_mutex; 

	std::string m_host;
	int m_port;
	std::string m_db;
	std::string m_user;
	std::string m_passwd;
	std::string m_charset;

	MYSQL *mysql_instance;
};

#endif
