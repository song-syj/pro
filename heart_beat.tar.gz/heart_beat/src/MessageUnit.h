#ifndef _MESSAGE_UNIT_H
#define _MESSAGE_UNIT_H

#include<stdint.h>
#include<string>
#include<list>
#include<cstdlib>
#include<cstring>
#include"Common.h"

class MessageUnit {
public:
    enum MessageType {
	USER_LOGIN_REQUEST 			= 10001,
	USER_LOGIN_SUCCESS 			= 10002,
	USER_LOGIN_FAIL    			= 10003,
	USER_LIST_REQUEST  			= 10004,
	USER_LIST_ACK      			= 10005,
	USER_LIST_COMPLETE 			= 10006,
	USER_CHAT_RECORDS_REQUEST	= 10007,
	USER_CHAT_RECORDS_ACK   	= 10008,
	USER_CHAT_RECORDS_FAIL   	= 10009,
	USER_CHAT_RECORDS_COMPLETE	= 10010,
	HEART_BEAT_QUERY   			= 10011,
	HEART_BEAT_ACK     			= 10012,
	USER_CHAR_MESSAGE  			= 10013,
	USER_MESSAGE_RECV_ACK 		= 10014,
	USER_MESSAGE_RECV_FAIL 		= 10015,
	USER_LOGOUT_REQUEST 		= 10016,
    };
    MessageUnit(){}
    virtual void parse(DataPackage &data_pack) = 0;
    virtual DataPackage* assemble() const = 0;
    virtual MessageUnit::MessageType MessageTypeID() const = 0;
    virtual ~MessageUnit(){}

};

class LoginRequestMessage: public MessageUnit {
public:
	LoginRequestMessage() :MessageUnit() {}
    LoginRequestMessage (const uint32_t uid, const char* passwd)
        :user_id(uid), password(passwd){}

	void parse(DataPackage &data_pack)
	{
		user_id = ((LoginInfo *)(data_pack.data))->user_id;
		password = ((LoginInfo *)(data_pack.data))->passwd;
	}

    DataPackage* assemble() const
    {
        DataPackage *pack = (DataPackage *)malloc(sizeof(DataPackage)+ sizeof(LoginInfo));
		if (pack == NULL) {
			log_crit("malloc for DataPackage error");
			return NULL;
		}

        pack->type = USER_LOGIN_REQUEST;
        pack->length = sizeof(LoginInfo);

        LoginInfo *pLogin = (LoginInfo *)pack->data;
		pLogin->user_id = user_id;
        strncpy(pLogin->passwd, password.c_str(), sizeof(pLogin->passwd)-1);
		pLogin->passwd[MAX_PASSWD_LEN] = '\0';

        return pack;
    }

    MessageUnit::MessageType MessageTypeID() const
    { return USER_LOGIN_REQUEST;}


    uint32_t user_id;
	std::string password;
};

class LoginSucessMessage: public MessageUnit {
public:
	LoginSucessMessage() {}
	LoginSucessMessage(PeerInfo &peer_info) : user_info(peer_info) {}
	void parse(DataPackage &data_pack)
	{
		user_info = *(PeerInfo *)(data_pack.data);
	}

    DataPackage* assemble() const
    {
        DataPackage *pack = (DataPackage *)malloc(sizeof(DataPackage) +sizeof(PeerInfo));
		if (pack == NULL) {
			log_crit("malloc for DataPackage error");
			return NULL;
		}
		*((PeerInfo *)pack->data) = user_info;
        pack->type = MessageUnit::USER_LOGIN_SUCCESS;
        pack->length = sizeof(PeerInfo);

        return pack;
    }

	const PeerInfo & GetPeerInfo()
	{
		return user_info;
	}

    MessageUnit::MessageType MessageTypeID() const
    { return USER_LOGIN_SUCCESS;}

private:
	PeerInfo user_info;
};

class LoginFailMessage: public MessageUnit {
public:
	void parse(DataPackage &data_pack)
	{
	}

    DataPackage* assemble() const
    {
        DataPackage *pack = (DataPackage *)malloc(sizeof(DataPackage));
		if (pack == NULL) {
			log_crit("malloc for DataPackage error");
			return NULL;
		}

        pack->type = MessageUnit::USER_LOGIN_FAIL;
        pack->length = 0;

        return pack;
    }

    MessageUnit::MessageType MessageTypeID() const
     { return USER_LOGIN_FAIL;}

};

class LogoutRequestMessage: public MessageUnit {
public:
	void parse(DataPackage &data_pack)
	{
	}

    DataPackage* assemble() const
    {
        DataPackage *pack = (DataPackage *)malloc(sizeof(DataPackage));
		if (pack == NULL) {
			log_crit("malloc for DataPackage error");
			return NULL;
		}

        pack->type = MessageUnit::USER_LOGOUT_REQUEST;
        pack->length = 0;

        return pack;
    }

    MessageUnit::MessageType MessageTypeID() const
     { return USER_LOGOUT_REQUEST;}

};
class UserListRequestMessage: public MessageUnit {
public:
	void parse(DataPackage &data_pack)
	{
	}

    DataPackage* assemble() const
    {
        DataPackage *pack = (DataPackage *)malloc(sizeof(DataPackage));
		if (pack == NULL) {
			log_crit("malloc for DataPackage error");
			return NULL;
		}

        pack->type = MessageUnit::USER_LIST_REQUEST;
        pack->length = 0;

        return pack;
    }

    MessageUnit::MessageType MessageTypeID() const
    { return USER_LIST_REQUEST;}
};

class UserListAckMessage: public MessageUnit {
public:
	void parse(DataPackage &data_pack)
	{
		PeerListInfo *pList = (PeerListInfo *)data_pack.data;
		for(int i = pList->size - 1; i >= 0; i--) {
			peer_list.push_back(pList->peerlist[i]);
		}
	}

    DataPackage* assemble() const
    {
        DataPackage *pack = (DataPackage *)malloc(sizeof(DataPackage)+sizeof(PeerListInfo));
		if (pack == NULL) {
			log_crit("malloc for DataPackage error");
			return NULL;
		}

        pack->type = MessageUnit::USER_LIST_ACK;
        pack->length = sizeof(PeerListInfo);

        PeerListInfo *pList = (PeerListInfo *)pack->data;
        pList->size = peer_list.size();

        int i = 0;
        for (std::list<PeerInfo>::const_iterator iter = peer_list.begin();
        		iter != peer_list.end(); iter++) {
        	pList->peerlist[i++] = *iter;
        }

        return pack;
    }

    MessageUnit::MessageType MessageTypeID() const
    { return USER_LIST_ACK;}

	std::list<PeerInfo> peer_list;
};

class UserListComplete: public MessageUnit {
public:
	void parse(DataPackage &data_pack)
	{

	}

    DataPackage* assemble() const
    {
        DataPackage *pack = (DataPackage *)malloc(sizeof(DataPackage));
		if (pack == NULL) {
			log_crit("malloc for DataPackage error");
			return NULL;
		}

        pack->type = MessageUnit::USER_LIST_COMPLETE;
        pack->length = 0;

        return pack;
    }

    MessageUnit::MessageType MessageTypeID() const
    { return USER_LIST_COMPLETE;}

};

class UserChatRecordRequestMessage: public MessageUnit {
public:
	UserChatRecordRequestMessage() {}
	void parse(DataPackage &data_pack)
	{
	}

    DataPackage* assemble() const
    {
        DataPackage *pack = (DataPackage *)malloc(sizeof(DataPackage));
		if (pack == NULL) {
			log_crit("malloc for DataPackage error");
			return NULL;
		}

        pack->type = MessageUnit::USER_CHAT_RECORDS_REQUEST;
        pack->length = 0;

        return pack;
    }

    MessageUnit::MessageType MessageTypeID() const
    { return USER_CHAT_RECORDS_REQUEST;}
};

class UserChatRecordAckMessage: public MessageUnit {
public:
	UserChatRecordAckMessage(ChatRecordItems &record_items) 
		:records(record_items) {}

	UserChatRecordAckMessage() {}
	void parse(DataPackage &data_pack)
	{
		ChatRecordSet* ptr_record = (ChatRecordSet *)data_pack.data;
		records.clear();
		for(int i = 0; i < ptr_record->size; i++) {
			records.push_back(ptr_record->chat_items[i]);
		}
	}

    DataPackage* assemble() const
    {
        DataPackage *pack = (DataPackage *)malloc(sizeof(DataPackage) + sizeof(ChatRecordSet));
		if (pack == NULL) {
			log_crit("malloc for DataPackage error");
			return NULL;
		}
        pack->type = MessageUnit::USER_CHAT_RECORDS_ACK;
        pack->length = sizeof(ChatRecordSet);
		ChatRecordSet* ptr_records = (ChatRecordSet *)pack->data;

		ptr_records->size = records.size();
		int i = 0;
		for (std::vector<ChatRecord>::const_iterator
				iter = records.begin(); 
				iter != records.end(); iter++) {
			ptr_records->chat_items[i++] = *iter;
		}

        return pack;
    }

    MessageUnit::MessageType MessageTypeID() const
    { return USER_CHAT_RECORDS_ACK;}

	ChatRecordItems records;
};

class UserChatRecordCompleteMessage: public MessageUnit {
public:
	void parse(DataPackage &data_pack)
	{
	}

    DataPackage* assemble() const
    {
        DataPackage *pack = (DataPackage *)malloc(sizeof(DataPackage));
		if (pack == NULL) {
			log_crit("malloc for DataPackage error");
			return NULL;
		}

        pack->type = MessageUnit::USER_CHAT_RECORDS_COMPLETE;
        pack->length = 0;

        return pack;
    }

    MessageUnit::MessageType MessageTypeID() const
    { return USER_CHAT_RECORDS_COMPLETE;}

};

class HeartBeatQuery: public MessageUnit {
public:
	void parse(DataPackage &data_pack)
	{
	}

    DataPackage* assemble() const
    {
        DataPackage *pack = (DataPackage *)malloc(sizeof(DataPackage));
		if (pack == NULL) {
			log_crit("malloc for DataPackage error");
			return NULL;
		}

        pack->type = MessageUnit::HEART_BEAT_QUERY;
        pack->length = 0;

        return pack;
    }

    MessageUnit::MessageType MessageTypeID() const
    { return HEART_BEAT_QUERY;}

};

class HeartBeatAck: public MessageUnit {
public:
	void parse(DataPackage &data_pack)
	{

	}

    DataPackage* assemble() const
    {
        DataPackage *pack = (DataPackage *)malloc(sizeof(DataPackage));
		if (pack == NULL) {
			log_crit("malloc for DataPackage error");
			return NULL;
		}

        pack->type = MessageUnit::HEART_BEAT_ACK;
        pack->length = 0;

        return pack;
    }

    MessageUnit::MessageType MessageTypeID() const
    { return HEART_BEAT_ACK;}

};

class UserChatMessage: public MessageUnit {
public:
	UserChatMessage(PeerInfo &src, PeerInfo &des, std::string &text)
		: chat_text(text) 
	{
		src_peer=src;
	   	des_peer=des;
	}
	UserChatMessage() {}

   	void parse(DataPackage &data_pack)
	{
		ChatMessage *pmsg = (ChatMessage *)data_pack.data;
		src_peer = pmsg->src;
		des_peer = pmsg->des;
		chat_text = pmsg->text;
	}

    DataPackage* assemble() const
    {
        DataPackage *pack = (DataPackage *)malloc(sizeof(DataPackage)+sizeof(ChatMessage));
		if (pack == NULL) {
			log_crit("malloc for DataPackage error");
			return NULL;
		}

        pack->type = MessageUnit::USER_CHAR_MESSAGE;
        pack->length = sizeof(ChatMessage);

		ChatMessage *pmsg = (ChatMessage *)pack->data;
		pmsg->src = src_peer;
		pmsg->des = des_peer;
		strcpy(pmsg->text, chat_text.c_str());

        return pack;
    }

    MessageUnit::MessageType MessageTypeID() const
    { return MessageUnit::USER_CHAR_MESSAGE;}

    const std::string & GetChatContent() const
    {
    	return chat_text;
    }

	const PeerInfo & GetSrcPeer()
	{
		return src_peer;
	}

	const PeerInfo & GetDesPeer()
	{
		return des_peer;
	}

private:
PeerInfo src_peer;
PeerInfo des_peer;
std::string chat_text;
};

class MessageRecvAck:public MessageUnit {
public:
   	void parse(DataPackage &data_pack)
	{
	}

    DataPackage* assemble() const
    {
        DataPackage *pack = (DataPackage *)malloc(sizeof(DataPackage));
		if (pack == NULL) {
			log_crit("malloc for DataPackage error");
			return NULL;
		}

        pack->type = MessageUnit::USER_MESSAGE_RECV_ACK;
        pack->length = 0;

        return pack;
    }

    MessageUnit::MessageType MessageTypeID() const
    { return MessageUnit::USER_MESSAGE_RECV_ACK;}

};


class MessageRecvFail:public MessageUnit {
public:
   	void parse(DataPackage &data_pack)
	{
	}

    DataPackage* assemble() const
    {
        DataPackage *pack = (DataPackage *)malloc(sizeof(DataPackage));
		if (pack == NULL) {
			log_crit("malloc for DataPackage error");
			return NULL;
		}

        pack->type = MessageUnit::USER_MESSAGE_RECV_FAIL;
        pack->length = 0;

        return pack;
    }

    MessageUnit::MessageType MessageTypeID() const
    { return MessageUnit::USER_MESSAGE_RECV_FAIL;}

};

class LogoutRequest {
public:
   	void parse(DataPackage &data_pack)
	{
	}

    DataPackage* assemble() const
    {
        DataPackage *pack = (DataPackage *)malloc(sizeof(DataPackage));
		if (pack == NULL) {
			log_crit("malloc for DataPackage error");
			return NULL;
		}

        pack->type = MessageUnit::USER_LOGOUT_REQUEST;
        pack->length = 0;

        return pack;
    }

    MessageUnit::MessageType MessageTypeID() const
    { return MessageUnit::USER_LOGOUT_REQUEST;}

};
#endif
