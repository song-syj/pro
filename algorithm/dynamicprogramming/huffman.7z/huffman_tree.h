#ifndef _HUFFMAN_TREE_H
#define _HUFFMAN_TREE_H

#include "types.h"
#define NUM_CHAR 256

typedef struct huffman_node {
	Uint8 charater;
	Uint32 freq;

	struct huffman_node *left;
	struct huffman_node *right;
} huffman_node;


huffman_node *build_huffman_tree(Uint32 freq[NUM_CHAR]);
void delete_huffman_tree(huffman_node *huffman_tree);
void huffman_tree_display(huffman_node *tree);

#endif