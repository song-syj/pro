#include "huffman.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>




void stastics_charaters(String str, Uint32 len, Uint32 freq[NUM_CHAR]);
void frequence_preprocess(Uint32 freq[NUM_CHAR]);

void create_code_table(huffman_node *huffman_tree, huffman_char_code table[NUM_CHAR]);
void print_code_table(huffman_char_code table[NUM_CHAR], String filename);

void creat_header(Uint32 freq[NUM_CHAR], Uint8 *header, Uint32 len);
compress_pos huffman_compress(String str, Uint32 len, String cmp, Uint8 position, huffman_char_code table[NUM_CHAR]);
uncompress_pos huffman_uncompress(huffman_node *huffman_tree,String str, Uint8 pos, Uint32 len, String uncmp);

Bool huffman_coder(String infilename, String outfilename);
Bool huffman_decoder(String infilename, String outfilename);




static void create_table_crc(huffman_node *huffman_tree, huffman_char_code table[NUM_CHAR], Uint8 code[MAX_CODE_LEN], Uint8 deep);
static void set_bit(Uint8 *code, Uint32 pos, Uint8 bit);
static Uint8 get_bit(Uint8 *code, Uint32 pos);

void
stastics_charaters(String str, Uint32 len, Uint32 freq[NUM_CHAR])
{
	Uint32 i;
	Uint8 num ;
	Uint32 max;
	max = 0;
	//memset(freq, 0, sizeof(Uint32)*NUM_CHAR);
	for (i = 0; i < len; i++) {
		num = str[i];
		freq[num] ++;
	}

}

void 
frequence_preprocess(Uint32 freq[NUM_CHAR])
{
	Uint32 max = 0;
	Uint32 i;
	for(i = 0; i < NUM_CHAR; i++) {
		if(max < freq[i])
			max = freq[i];
	}
	//prevent max frequence exceed the max value of Uint32
	//in the process of building huffman tree
	if(max > 0xffffff) {
		for (i = 0; i < NUM_CHAR; i++) {
			if(freq[i] > 0) {
				freq[i] = (Uint32)(freq[i] * (double)0xffffff / max );
				if(freq[i] == 0)
					freq[i] = 1;
			}
		}
	}
}
void freq_print(Uint32 freq[NUM_CHAR])
{
	Uint16 i;
	FILE *pfile;
	pfile = fopen("freq_table.txt","w");
	for(i = 0; i < NUM_CHAR; i++) {
		if(freq[i] > 0)
			fprintf(pfile, "freq[%d] : %d\n", i, freq[i]);
	}
	fclose(pfile);
}
void 
create_code_table(huffman_node *huffman_tree, huffman_char_code table[NUM_CHAR])
{
	Uint8 deep = 0;
	Uint16 i;
	Uint8 code[MAX_CODE_LEN] ={0};
	for(i = 0; i < NUM_CHAR; i++) {
		table[i].used =False;
	}
	
	create_table_crc(huffman_tree, table, code, deep);
}

void
print_code_table(huffman_char_code table[NUM_CHAR], String filename)
{
	Uint16 i;
	Uint8 j;
	Uint8 bitc;
	FILE *pfile;
	pfile = fopen(filename, "w");
	for (i = 0; i < NUM_CHAR; i++) {
		if(table[i].used == True) {
			fprintf(pfile,"code[%d] :", i);
			for(j = 0; j < table[i].size; j++) {
				bitc = get_bit(table[i].code, j) + '0';
				fputc(bitc, pfile);
			}
			fputc('\n', pfile);
		}
	}
	fclose(pfile);
}
// suggest that the length of compressing string is not more than 1000 
compress_pos huffman_compress(String str, Uint32 len, String cmp, Uint8 position, huffman_char_code table[NUM_CHAR])
{
	Uint32 i, j;
	Uint32 pos;
//	Uint32 bsize;
	Uint8 ch;
	compress_pos cmp_pos;
	pos = position;
	for(i = 0; i < len; i++ ) {
		ch = str[i];
		for(j = 0; j < table[ch].size; j++) {
			set_bit((Uint8 *)cmp, j+pos,get_bit(table[ch].code, j));
		}
		pos += table[ch].size;
	}
	cmp_pos.bsize = pos / 8;
	cmp_pos.pos = pos % 8;

	return cmp_pos;
}

uncompress_pos huffman_uncompress(huffman_node *huffman_tree,String str, Uint32 len, Uint8 pos, String uncmp_str)
{
	Uint32 bit_pos;
	Uint32 prev_pos;
	Uint32 i;
	Uint32 bit;
	Uint16 uncmp_len;
	uncompress_pos umcmp_pos;
	huffman_node *root;

	bit_pos = pos;
	prev_pos = pos;
	uncmp_len = 0;

	while(1) {
		root = huffman_tree;
		while((root->left != NULL ||
			root->right != NULL ) &&
			(bit_pos < len * 8)) {
				bit = get_bit((Uint8 *)str, bit_pos++);
				if(bit == 0)
					root =  root->left;
				else
					root = root->right;
		}
		if (bit_pos < len * 8) {
			uncmp_str[uncmp_len++] = root->charater;
			prev_pos = bit_pos;
		}
		else {
			umcmp_pos.pos = prev_pos % 8;
			umcmp_pos.bsize = prev_pos / 8;
			umcmp_pos.uncmp_len = uncmp_len;
			break;
		}
	}
	return umcmp_pos;
	
}

Bool
huffman_coder(String infilename, String outfilename)
{
	FILE *pfilein, *pfileout;
	Uint16 size;
	Uint32 fsize;
	Uint8 *header;
	Uint32 freq[NUM_CHAR];
	huffman_char_code table[NUM_CHAR];
	huffman_node *huffman_tree;
	compress_pos comp_pos;

	//int sum = 0;
	int i = 0;

	String string_buffer; //the string from the infile
	String cmp_buffer;  // the string compressed

	pfilein = fopen(infilename, "rb");
	//fopen_s(&pfileout, "infiledata.txt", "wb");
	// not cmpress a  file that doesn't exist
	if(pfilein == NULL) {
		printf("The compressing file is not exist!\n");
		return False;
	}
	// not cmpress a empty file
	if(feof(pfilein)) {
		printf("The compressing file is empty!\n");
		return False;
	}

	string_buffer = (String)malloc(sizeof(Uint8) * RW_LEN);
	memset(freq, 0, sizeof(Uint32) * NUM_CHAR);
	fsize = 0;
	do {
		size = fread(string_buffer, sizeof(Uint8), RW_LEN,pfilein);
		if(size > 0) {
		/*	for(i =0; i < size; i++)
				fprintf_s(pfileout, "%02x\r\n", string_buffer[i]);*/
			stastics_charaters(string_buffer, size, freq);
			fsize += size;
			i++;
		}
	} while (size == RW_LEN);
	fclose(pfilein);
	freq_print(freq);
	frequence_preprocess(freq);
	//fclose(pfileout);
	// construct a huffman_tree;
	
	huffman_tree = build_huffman_tree(freq);
	//huffman_tree_display(huffman_tree);
	// create charater code table
	create_code_table(huffman_tree, table);
	print_code_table(table, "compress_table.txt");
	delete_huffman_tree(huffman_tree);

	pfilein = fopen(infilename, "rb");
	pfileout = fopen(outfilename, "wb");
	//pfilein = fopen(infilename, "rb");
	//pfileout = fopen(outfilename, "wb");

	//write header information to the outfile
	header = (Uint8 *)malloc(HEADERSIZE);
	creat_header(freq, header, fsize);
	fwrite(header, sizeof(Uint8), HEADERSIZE, pfileout);
	free(header);

	//compress the context of the infile
	comp_pos.bsize = 0;
	comp_pos.pos = 0;
	cmp_buffer = (String) malloc(sizeof(Uint8)*RW_LEN);
	do {
		size = fread(string_buffer, sizeof(Uint8), RW_LEN,pfilein);
		if(size > 0) {
			comp_pos = huffman_compress(string_buffer, size, cmp_buffer, comp_pos.pos, table);
			fwrite(cmp_buffer, sizeof(Uint8), comp_pos.bsize, pfileout);
			memcpy(cmp_buffer, cmp_buffer + comp_pos.bsize,sizeof(Uint8));
		}
	} while (size == RW_LEN);
	fwrite(cmp_buffer, sizeof(Uint8), 1, pfileout); //write the end part of codes that less than a type; 

	free(cmp_buffer);
	free(string_buffer);

	fclose(pfilein);
	fclose(pfileout);


	return True;
}	

Bool huffman_decoder(String infilename, String outfilename)
{
	FILE *pfilein, *pfileout;	
	Uint16 size;
	Uint32 fsize;
	Uint8 *header;
	Uint8 remain_bytes;
	String string_buffer;//temp buffer for data read from infile
	String ucmp_buffer; //temp buffer for uncompressed data
	Uint32 freq[NUM_CHAR];
	huffman_char_code table[NUM_CHAR];
	huffman_node *huffman_tree;
	uncompress_pos uncomp_pos;

	pfilein = fopen(infilename, "rb");
	// not cmpress a  file that doesn't exist
	if(pfilein == NULL) {
		printf("The compressd file is not exist!\n");
		return False;
	}
	// not cmpress a empty file
	if(feof(pfilein)) {
		printf("The compressd file is empty!\n");
		return False;
	}

	memset(freq, 0, sizeof(Uint32) * NUM_CHAR);
	fread(&fsize, sizeof(Uint32), 1, pfilein);
	fread(freq, sizeof(Uint32), NUM_CHAR, pfilein);

	huffman_tree = build_huffman_tree(freq);
	create_code_table(huffman_tree, table);
	print_code_table(table, "uncompress_table.txt");
	//huffman_tree_display(huffman_tree);

	pfileout = fopen(outfilename, "wb");

	string_buffer = (String)malloc(sizeof(Uint8) * (RW_LEN/8+32)); //
	ucmp_buffer = (String)malloc(sizeof(Uint8) * (RW_LEN+32));
	uncomp_pos.bsize = 0;
	uncomp_pos.pos = 0;
	uncomp_pos.uncmp_len = 0;
	remain_bytes = 0;
	do {
		size = fread(string_buffer+remain_bytes, sizeof(Uint8), RW_LEN/8,pfilein);
		if(size > 0) {
			uncomp_pos = huffman_uncompress(huffman_tree, string_buffer, 
				size + remain_bytes, uncomp_pos.pos ,ucmp_buffer);
			if(uncomp_pos.uncmp_len < fsize) {
				fwrite(ucmp_buffer, sizeof(Uint8), uncomp_pos.uncmp_len, pfileout);
				fsize -= uncomp_pos.uncmp_len;
				remain_bytes = size + remain_bytes - uncomp_pos.bsize;
				memcpy(string_buffer, string_buffer + uncomp_pos.bsize, remain_bytes);
			} else {
				fwrite(ucmp_buffer, sizeof(Uint8), fsize, pfileout);
				fclose(pfileout);
				break;
			}
		}
	} while (size == RW_LEN/8);

	delete_huffman_tree(huffman_tree);
	free(string_buffer);
	fclose(pfilein);
}

	//for(i = 0; i < len; i++ ) {
	//	ch = str[i];
	//	for(j = 0; j < table[ch].size; j++) {
	//		set_bit((Uint8 *)ptr, j+pos,get_bit(table[ch].code, j));
	//	}
	//	pos += table[ch].size;
	//	bytesize += pos / 8; //writed bytes size
	//	pos = pos % 8;		//a bit position that we want to write in a byte
	//	ptr = ptr + bytesize;// a byte position that we want to write in a string
	//}
	//if(pos > 0)
	//	bytesize++;
void 
creat_header(Uint32 freq[NUM_CHAR], Uint8 *header, Uint32 len)
{
	Uint32 i;
	memcpy(header, &len, sizeof(Uint32));
	// store the scaled frequencies for all symbols in the character set
	for (i = 0; i < NUM_CHAR; i++) {
		memcpy(header+sizeof(Uint32)+ i* sizeof(Uint32),
			freq+i, sizeof(Uint32));
	}
	return;
}
static void
create_table_crc(huffman_node *huffman_tree, huffman_char_code table[NUM_CHAR], Uint8 code[MAX_CODE_LEN], Uint8 deep)
{
	
	if (huffman_tree == NULL)
		return;

	if(huffman_tree->left == NULL 
		&& huffman_tree->right ==NULL) {
			Uint8 ch = huffman_tree->charater; //get the coded character
			table[ch].used = True;
			table[ch].size = deep;
			memcpy(table[ch].code, code, sizeof(Uint8)*MAX_CODE_LEN);
	}
	if(huffman_tree->left != NULL) {
		set_bit(code, deep, 0);
		create_table_crc(huffman_tree->left, table, code, deep+1);
	}
	if(huffman_tree->right != NULL) {
		set_bit(code, deep, 1);
		create_table_crc(huffman_tree->right, table, code, deep+1);
	}
}
static void
set_bit(Uint8 *code,Uint32 pos, Uint8 bit )
{
	Uint8 mask = 0x80;
	mask = mask >> (pos%8);
	if (bit == 0)
		code[pos/8] = code[pos/8] & (~mask);
	else
		code[pos/8] = code[pos/8] | mask;
}

static Uint8
get_bit(Uint8 *code,Uint32 pos)
{
	Uint8 mask = 0x80;
	Uint8 bit;
	mask = mask >> (pos%8) ;
	bit = (code[pos/8] & mask) == mask ? 1 : 0 ;
	return bit;
}
