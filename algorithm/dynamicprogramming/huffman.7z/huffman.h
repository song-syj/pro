#ifndef _HUFFMAN_H
#define _HUFFMAN_H

#include "types.h"
#include "huffman_tree.h"

#define MAX_CODE_LEN 32
#define RW_LEN 1000
#define HEADERSIZE (4*(NUM_CHAR+1))

typedef struct huffman_code {
	Bool used ;
	Uint8 size;
	Uint8 code[MAX_CODE_LEN];
}huffman_char_code;

typedef struct compress_pos {
	Uint8 pos;
	Uint32 bsize;
}compress_pos;

typedef struct uncompress_pos {
	Uint8 pos;
	Uint32 bsize;
	Uint32 uncmp_len;//the length uncompressed string
}uncompress_pos;


void stastics_charaters(String str, Uint32 len, Uint32 freq[NUM_CHAR]);
void frequence_preprocess(Uint32 freq[NUM_CHAR]);

void create_code_table(huffman_node *huffman_tree, huffman_char_code table[NUM_CHAR]);
void print_code_table(huffman_char_code table[NUM_CHAR]);

void creat_header(Uint32 freq[NUM_CHAR], Uint8 *header, Uint32 len);
compress_pos huffman_compress(String str, Uint32 len, String cmp, Uint8 position, huffman_char_code table[NUM_CHAR]);
uncompress_pos huffman_uncompress(huffman_node *huffman_tree,String str, Uint32 len, Uint8 pos, String uncmp);

Bool huffman_coder(String infilename, String outfilename);
Bool huffman_decoder(String infilename, String outfilename);


#endif