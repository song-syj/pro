#include <stdio.h>
#include "huffman.h"

int main(void)
{
	huffman_coder("test.txt","huffman_code.bin");
	huffman_decoder("huffman_code.bin","test_copy.txt");
	return 0;
}