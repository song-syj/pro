/*
 * types.h
 *
 *  Created on: Oct 23, 2013
 *      Author: song
 */

#ifndef TYPES_H_
#define TYPES_H_

typedef char Int8;
typedef unsigned char Uint8;
typedef short Int16;
typedef unsigned short Uint16;
typedef int Int32;
typedef unsigned int Uint32;


#define True 1
#define False 0
typedef Uint8 Bool;

typedef char *String;

#endif /* TYPES_H_ */
