#include "huffman_tree.h"
#include "prior_queue.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>


#define MAXSTACKSIZE 100
static huffman_node *stack[MAXSTACKSIZE];
static int top = 0;

static void  swap(void **a, void **b);
static Int8 compare(void *a, void *b);

huffman_node *
build_huffman_tree(Uint32 freq[NUM_CHAR])
{
	prior_queue *ptr_que; 
	huffman_node *ptr_node;
	huffman_node *ptr_left, *ptr_right,*ptr_root;
	Uint32 freq_ex[NUM_CHAR] = {0};
	Uint16 i;
	Bool bl;
	ptr_que = build_prior_queue(NUM_CHAR, compare, swap);
	for(i = 0; i < NUM_CHAR; i++)
	{
		if(freq[i] > 0) {
			ptr_node = (huffman_node *)malloc(sizeof(huffman_node));
			ptr_node->charater = i;
			ptr_node->freq = freq[i];
			ptr_node->left = NULL;
			ptr_node->right = NULL;

			if( insert_prior_queue(ptr_que,  (void *)ptr_node) == False)
				break;
		}
	}
	//test prior_queue
	//for(i = 0; i < NUM_CHAR; i++) {
	//	if(freq[i] > 0)
	//		printf("c: %d ,freq: %d\n", i, freq[i]);
	//}
	/*while(ptr_que->size) {
		ptr_left = (huffman_node *)extract_head(ptr_que);
		freq_ex[ptr_left->charater] = ptr_left->freq;
		printf("c: %d ,freq: %d\n", ptr_left->charater, ptr_left->freq);
	}
	bl = False;
	for(i = 0; i < NUM_CHAR; i++) {
		if(freq_ex[i] != freq[i])
			bl = True;
	}*/
	while(ptr_que->size > 1) {
		ptr_left = (huffman_node *)extract_head(ptr_que);
		ptr_right = (huffman_node *)extract_head(ptr_que);
		ptr_root = (huffman_node *)malloc(sizeof(huffman_node));
		ptr_root->freq = ptr_left->freq + ptr_right->freq ;
		ptr_root->left = ptr_left;
		ptr_root->right = ptr_right;
		insert_prior_queue(ptr_que, (void *)ptr_root);
	}
	ptr_node = (huffman_node *)extract_head(ptr_que);
	delete_prior_queue(ptr_que);

	return ptr_node;
}

void
huffman_tree_display(huffman_node *tree)
{
	huffman_node *p;
	huffman_node tmp;
	
	int i, t,width,widthMax; 
	tmp.freq = 0;
	width = 4;
	widthMax = 40;
	t = width;
	if(tree == NULL) {
		printf("Empty tree!\n");
		return ;
	}
	stack[++top] = tree;
	while(top > 0) {
		p = stack[top--];
		for(i=0; i < t; i++)
			putchar(' ');
		if(p == &tmp) {
			putchar(')');
			for(i = t-3; i < widthMax; i++)
				putchar('-');
		    putchar('\n');
			t -= width;
			continue;
		} else {
			if(p == NULL)
				printf(" NIL");
			else {
				printf("(%4d", p->freq);
				if(p->left == NULL &&
				p->right == NULL)
				printf("{%d}",p->charater);
			}
		}
		for(i = t; i < widthMax; i++)
			putchar('-');
		putchar('\n');
		if(p->left != NULL ||
				p->right != NULL) {
			stack[++top] = &tmp;
			stack[++top] = p->right;
			stack[++top] = p->left;
			t += width;
		}
	}

}
void 
delete_huffman_tree(huffman_node *huffman_tree)
{
	if(huffman_tree == NULL)
		return;
	delete_huffman_tree(huffman_tree->left);
	delete_huffman_tree(huffman_tree->right);
	free(huffman_tree);
}

static void 
swap(void **a, void **b)
{
	huffman_node *tmp;
	tmp = *(huffman_node **)a;
	*(huffman_node **)a = *(huffman_node**)b;
	*(huffman_node **)b =tmp;
}

static Int8 
compare(void *a, void *b)
{
	if (((huffman_node*)a)->freq < ((huffman_node*)b)->freq)
		return -1;
	else if (((huffman_node*)a)->freq > ((huffman_node*)b)->freq)
		return 1;
	else
		return 0;
}