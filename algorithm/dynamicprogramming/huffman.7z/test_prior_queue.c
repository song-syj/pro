#include <stdio.h>
#include "types.h"
#include "prior_queue.h"
#include <stdlib.h>
#include <time.h>

void swap(void **a, void **b);
Int8 compare(void *a, void *b);
void print_queue(prior_queue *ptr_que);

int main(void)
{
	int testdata[100]= {345,362,480,575,622,936,710,737,578,805};
	prior_queue *ptr_que;
	int prev,curr;
	int i , n;
	srand(time(NULL));
	for(i = 0; i < 100; i++)
		testdata[i] = (int)rand() % 1000;
	ptr_que = build_prior_queue(100, compare, swap);
	n = 100;
	for(i = 0; i < n;i ++) {
		if( insert_prior_queue(ptr_que, (void *)(testdata+i)) == False)
			break;
	}
	prev = 0;
	i = 0;
	while(ptr_que->size > 0) {
		curr = *(int *)extract_head(ptr_que);
		printf("%d ", curr);
		i++;
		if(curr < prev)
			printf("error\n");
		prev = curr;
	}
	printf("\nthe num : %d\n", i);
	delete_prior_queue(ptr_que);
	system("pause");
}

Int8 compare(void *a, void *b)
{
	if (*(int*)a < *(int*)b)
		return -1;
	else if (*(int*)a > *(int*)b)
		return 1;
	else
		return 0;
}



void swap(void **a, void **b)
{
	int *tmp;
	tmp = *(int**)a;
	*(int **)a = *(int**)b;
	*(int**)b =tmp;
}

void print_queue(prior_queue *ptr_que)
{
	int i;
	for(i = 0 ;i < ptr_que->size; i++)
		printf("%d ", *(int *)ptr_que->ptr_node[i]);
	printf("\n");
}